"""Worker for the agents sample."""

# @@@SNIPSTART python-google-genai-agents-worker
import asyncio
import os

from google import genai
from temporalio.client import Client
from temporalio.google_genai import GoogleGenAIPlugin
from temporalio.worker import Worker

from google_genai.agents.workflow import AgentsWorkflow


async def main() -> None:
    genai_client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])
    plugin = GoogleGenAIPlugin(genai_client)

    client = await Client.connect(
        os.environ.get("TEMPORAL_ADDRESS", "localhost:7233"),
        plugins=[plugin],
    )

    worker = Worker(
        client,
        task_queue="google-genai-agents",
        workflows=[AgentsWorkflow],
    )
    print("Worker started. Ctrl+C to exit.")
    await worker.run()


if __name__ == "__main__":
    asyncio.run(main())
# @@@SNIPEND
