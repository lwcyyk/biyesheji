This sample shows how to expose a long-running Workflow's queries, updates, and signals as Nexus operations. This
version uses the experimental `@nexus.temporal_operation` decorator to allow Nexus operation handlers to either return
a synchronous result or start a Workflow as the async backing operation.

There are two self-contained examples, each in its own directory:

|                                | `callerpattern/`                     | `ondemandpattern/`                                           |
|--------------------------------|--------------------------------------|--------------------------------------------------------------|
| **Pattern**                    | Signal an existing Workflow          | Create and run Workflows on demand, and send signals to them |
| **Who creates the Workflow?**  | The handler worker starts it on boot | The caller starts it via a Nexus operation                   |
| **Who knows the Workflow ID?** | Only the handler                     | The caller chooses and passes it in every operation          |
| **Nexus service**              | `NexusGreetingService`               | `NexusRemoteGreetingService`                                 |

Each directory is fully self-contained for clarity. The `GreetingWorkflow`, activity, and
`Language` enum are **identical** between the two -- only the Nexus service definition and its
handler implementation differ. This highlights that the same Workflow can be exposed through
Nexus in different ways depending on whether the caller needs lifecycle control.

See each directory's README for running instructions.
