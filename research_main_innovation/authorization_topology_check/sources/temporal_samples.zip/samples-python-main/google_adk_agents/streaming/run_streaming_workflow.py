import asyncio
import os
from datetime import timedelta

from google.adk.models.llm_response import LlmResponse
from temporalio.client import Client
from temporalio.contrib.workflow_streams import WorkflowStreamClient
from temporalio.google_adk import GoogleAdkPlugin

from google_adk_agents.streaming.workflows.streaming_workflow import (
    StreamingAgentWorkflow,
)

WORKFLOW_ID = "google-adk-agents-streaming-workflow-id"


async def main():
    client = await Client.connect(
        os.environ.get("TEMPORAL_ADDRESS", "localhost:7233"),
        plugins=[GoogleAdkPlugin()],
    )

    handle = await client.start_workflow(
        StreamingAgentWorkflow.run,
        "Tell me a short story about a robot learning to paint.",
        id=WORKFLOW_ID,
        task_queue="google-adk-agents-streaming",
    )

    stream = WorkflowStreamClient.create(client, WORKFLOW_ID)

    async def print_chunks() -> None:
        print("Streaming response:")
        async for item in stream.subscribe(
            ["responses"],
            from_offset=0,
            result_type=LlmResponse,
            poll_cooldown=timedelta(milliseconds=50),
        ):
            response = item.data
            if response.content and response.content.parts:
                for part in response.content.parts:
                    if part.text:
                        print(part.text, end="", flush=True)

    chunk_task = asyncio.create_task(print_chunks())
    result = await handle.result()
    chunk_task.cancel()
    try:
        await chunk_task
    except asyncio.CancelledError:
        pass

    print(f"\n\nFinal result: {result}")


if __name__ == "__main__":
    asyncio.run(main())
