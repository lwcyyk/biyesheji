import asyncio
import os

from temporalio.client import Client
from temporalio.google_adk import GoogleAdkPlugin

from google_adk_agents.basic.workflows.hello_world_workflow import (
    HelloWorldAgentWorkflow,
)


async def main():
    # @@@SNIPSTART google-adk-agents-basic-starter
    client = await Client.connect(
        os.environ.get("TEMPORAL_ADDRESS", "localhost:7233"),
        plugins=[GoogleAdkPlugin()],
    )

    result = await client.execute_workflow(
        HelloWorldAgentWorkflow.run,
        "Tell me about recursion in programming.",
        id="google-adk-agents-basic-workflow-id",
        task_queue="google-adk-agents-basic",
    )
    print(f"Result: {result}")
    # @@@SNIPEND


if __name__ == "__main__":
    asyncio.run(main())
