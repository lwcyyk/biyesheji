# Temporal Python SDK Samples

This is a collection of samples showing how to use the [Python SDK](https://github.com/temporalio/sdk-python).

## Usage

Prerequisites:

* [uv](https://docs.astral.sh/uv/)
* [Temporal CLI](https://docs.temporal.io/cli) with a local dev server running:
  ```
  temporal server start-dev
  ```

The SDK requires Python >= 3.10. You can install Python using uv. For example,

    uv python install 3.13

With this repository cloned, run the following at the root of the directory:

    uv sync

That loads all required dependencies. Then to run a sample, usually you just run it under uv. For example:

    uv run hello/hello_activity.py

Some examples require extra dependencies. See each sample's directory for specific instructions.

## Samples

* [hello](hello) - All of the basic features.
  <!-- Keep this list in alphabetical order and in sync on hello/README.md and root README.md -->
  * [hello_activity](hello/hello_activity.py) - Execute an activity from a workflow.
  * [hello_activity_choice](hello/hello_activity_choice.py) - Execute certain activities inside a workflow based on
    dynamic input.
  * [hello_activity_method](hello/hello_activity_method.py) - Demonstrate an activity that is an instance method on a
    class and can access class state.
  * [hello_activity_multiprocess](hello/hello_activity_multiprocess.py) - Execute a synchronous activity on a process
    pool.
  * [hello_activity_retry](hello/hello_activity_retry.py) - Demonstrate activity retry by failing until a certain number
    of attempts.
  * [hello_activity_threaded](hello/hello_activity_threaded.py) - Execute a synchronous activity on a thread pool.
  * [hello_async_activity_completion](hello/hello_async_activity_completion.py) - Complete an activity outside of the
    function that was called.
  * [hello_cancellation](hello/hello_cancellation.py) - Manually react to cancellation inside workflows and activities.
  * [hello_change_log_level](hello/hello_change_log_level.py) - Change the level of workflow task failure from WARN to ERROR.
  * [hello_child_workflow](hello/hello_child_workflow.py) - Execute a child workflow from a workflow.
  * [hello_continue_as_new](hello/hello_continue_as_new.py) - Use continue as new to restart a workflow.
  * [hello_cron](hello/hello_cron.py) - Execute a workflow once a minute.
  * [hello_exception](hello/hello_exception.py) - Execute an activity that raises an error out of the workflow and out
    of the program.
  * [hello_local_activity](hello/hello_local_activity.py) - Execute a local activity from a workflow.
  * [hello_mtls](hello/hello_mtls.py) - Accept URL, namespace, and certificate info as CLI args and use mTLS for
    connecting to server.
  * [hello_parallel_activity](hello/hello_parallel_activity.py) - Execute multiple activities at once.
  * [hello_query](hello/hello_query.py) - Invoke queries on a workflow.
  * [hello_search_attributes](hello/hello_search_attributes.py) - Start workflow with search attributes then change
    while running.
  * [hello_signal](hello/hello_signal.py) - Send signals to a workflow.
  * [hello update](hello/hello_update.py) - Send a request to and a response from a client to a workflow execution.
<!-- Keep this list in alphabetical order -->
* [activity_worker](activity_worker) - Use Python activities from a workflow in another language.
* [batch_sliding_window](batch_sliding_window) - Batch processing with a sliding window of child workflows.
* [bedrock](bedrock) - Orchestrate a chatbot with Amazon Bedrock.
* [bedrock_agentcore/strands_agent](bedrock_agentcore/strands_agent) - Run a AWS Strands Agent with Temporal Plugin on AgentCore Worker.
* [claude_agent_sdk_plugin](claude_agent_sdk_plugin) - Run Claude Code agents as durable workflows with the Claude Agent SDK.
* [cloud_export_to_parquet](cloud_export_to_parquet) - Set up schedule workflow to process exported files on an hourly basis
* [context_propagation](context_propagation) - Context propagation through workflows/activities via interceptor.
* [custom_converter](custom_converter) - Use a custom payload converter to handle custom types.
* [custom_decorator](custom_decorator) - Custom decorator to auto-heartbeat a long-running activity.
* [custom_metric](custom_metric) - Custom metric to record the workflow type in the activity schedule to start latency.
* [deepagents_plugin](deepagents_plugin) - Make LangChain Deep Agents durable: each LLM/tool/backend call becomes a Temporal Activity while the agent loop replays in the Workflow.
* [dsl](dsl) - DSL workflow that executes steps defined in a YAML file.
* [eager_wf_start](eager_wf_start) - Run a workflow using Eager Workflow Start
* [encryption](encryption) - Apply end-to-end encryption for all input/output.
* [env_config](env_config) - Load client configuration from TOML files with programmatic overrides.
* [external_storage](external_storage) - Offload large payloads to S3-compatible object storage, plus a codec server for the Web UI and CLI.
* [external_storage_redis](external_storage_redis) - Redis driver for external storage
* [gevent_async](gevent_async) - Combine gevent and Temporal.
* [google_adk_agents](google_adk_agents) - Run Google ADK agents as durable Temporal workflows (model calls, tools, multi-agent, MCP, streaming).
* [google_genai](google_genai) - Run the Google Gemini SDK inside durable Temporal workflows.
* [hello_nexus](hello_nexus) - Define a Nexus service, implement operation handlers, and call them from a workflow.
* [hello_standalone_nexus](hello_standalone_nexus) - Use Nexus Operations without using a workflow.
* [hello_standalone_activity](hello_standalone_activity) - Use activities without using a workflow.
* [lambda_worker](lambda_worker) - Run a Temporal Worker inside an AWS Lambda function.
* [langfuse_tracing](langfuse_tracing) - Trace Temporal workflows in Langfuse with the OpenTelemetry plugin and OTLP export.
* [langgraph_plugin](langgraph_plugin) - Run LangGraph workflows as durable Temporal workflows (Graph API and Functional API).
* [langsmith_tracing](langsmith_tracing) - Trace Temporal workflows with LangSmith via the LangSmith plugin.
* [litellm_activity](litellm_activity) - Call LLM providers through LiteLLM from a Temporal Activity.
* [message_passing/introduction](message_passing/introduction/) - Introduction to queries, signals, and updates.
* [message_passing/safe_message_handlers](message_passing/safe_message_handlers/) - Safely handling updates and signals.
* [message_passing/update_with_start/lazy_initialization](message_passing/update_with_start/lazy_initialization/) - Use update-with-start to update a Shopping Cart, starting it if it does not exist.
* [nexus_cancel](nexus_cancel) - Fan out concurrent Nexus operations, take the first result, and cancel the rest.
* [nexus_messaging](nexus_messaging): Demonstrates how to send signal, update and query messages through Nexus.
  This contains two samples, one sending messages to an existing workflow and a second that creates a workflow through Nexus
  and sends messages to it.
* [nexus_messaging_temporal_operation](nexus_messaging_temporal_operation): Demonstrates how to send signal, update and query messages through Nexus.
  This version uses `@nexus.temporal_operation` to allow Nexus operation handlers to either return a synchronous result or start a Workflow as the async backing operation.
* [nexus_multiple_args](nexus_multiple_args) - Map a Nexus operation to a handler workflow that takes multiple arguments.
* [nexus_standalone_activity](nexus_standalone_activity) - Back a Nexus operation with a standalone Activity.
* [nexus_standalone_operations](nexus_standalone_operations) - Execute Nexus operations directly from client code,
without wrapping them in a workflow.
* [open_telemetry](open_telemetry) - Trace workflows with OpenTelemetry.
* [openai_agents](openai_agents) - Run OpenAI Agents SDK agents as durable Temporal workflows.
* [openrouter](openrouter) - Call OpenRouter from Activities: fan out a prompt batch, and pause instead of failing when the budget or credits run out.
* [patching](patching) - Alter workflows safely with `patch` and `deprecate_patch`.
* [polling](polling) - Recommended implementation of an activity that needs to periodically poll an external resource waiting its successful completion.
* [prometheus](prometheus) - Configure Prometheus metrics on clients/workers.
* [pydantic_converter](pydantic_converter) - Data converter for using Pydantic models.
* [pydantic_converter_v1](pydantic_converter_v1) - Data converter for Pydantic v1 models (prefer pydantic_converter for v2).
* [replay](replay) - Verify that workflow code changes are compatible with existing histories.
* [resource_pool](resource_pool) - Allocate a pool of shared resources across workflows.
* [schedules](schedules) - Demonstrates a Workflow Execution that occurs according to a schedule.
* [sentry](sentry) - Report errors to Sentry.
* [sleep_for_days](sleep_for_days) - A workflow that runs forever, sending an email every 30 days.
* [strands_plugin](strands_plugin) - Run Strands Agents as durable Temporal workflows (model calls, tools, MCP, HITL).
* [trio_async](trio_async) - Use asyncio Temporal in Trio-based environments.
* [updatable_timer](updatable_timer) - A timer that can be updated while sleeping.
* [worker_multiprocessing](worker_multiprocessing) - Leverage Python multiprocessing to parallelize workflow tasks and other CPU bound operations by running multiple workers.
* [worker_specific_task_queues](worker_specific_task_queues) - Use unique task queues to ensure activities run on specific workers.
* [worker_versioning](worker_versioning) - Use the Worker Versioning feature to more easily version your workflows & other code.
* [workflow_streams](workflow_streams) - Workflow-hosted durable event stream via `temporalio.contrib.workflow_streams`. **Experimental**

## Test

To run the tests:

    uv run poe test
