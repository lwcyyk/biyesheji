import {
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  Chip,
  Stack,
} from '@mui/material';
import { School, People, Business } from '@mui/icons-material';
import type { SvgIconComponent } from '@mui/icons-material';
import { useMemo } from 'react';
import { calculateStats } from '../utils/statsUtils';
import type { Paper } from '@/types/paper';

interface MetricItemProps {
  icon: SvgIconComponent;
  value: number;
  title?: string | undefined;
  color?: 'primary' | 'secondary';
}

const MetricItem: React.FC<MetricItemProps> = ({
  icon: Icon,
  value,
  title,
  color = 'primary',
}) => (
  <Stack
    direction="row"
    spacing={1.5}
    sx={{
      alignItems: 'center',
      flex: 1,
    }}
  >
    <Box
      sx={{
        width: { xs: 26, sm: 32 },
        height: { xs: 26, sm: 32 },
        borderRadius: 1,
        bgcolor: `${color}.light`,
        color: `${color}.dark`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
      }}
    >
      <Icon sx={{ fontSize: { xs: 14, sm: 18 } }} />
    </Box>
    <Box sx={{ flex: 1 }}>
      <Typography
        variant="h4"
        sx={{
          color: 'text.primary',
          fontSize: { xs: '1rem', sm: '1.75rem' },
          lineHeight: 1.2,
          fontWeight: 700,
        }}
      >
        {value}
      </Typography>
      <Typography
        variant="body2"
        sx={{
          color: 'text.secondary',
          fontSize: { xs: '0.7rem', sm: '0.8rem' },
        }}
      >
        {title}
      </Typography>
    </Box>
  </Stack>
);

interface StatCardProps {
  title: string;
  value: number;
  subtitle?: string;
  icon: SvgIconComponent;
  trend?: string;
  color?: 'primary' | 'secondary';
  secondaryValue?: number;
  secondaryTitle?: string;
  secondaryIcon?: SvgIconComponent;
  tertiaryValue?: number;
  tertiaryTitle?: string;
  tertiaryIcon?: SvgIconComponent;
}

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon,
  trend,
  color = 'primary',
  secondaryValue,
  secondaryTitle,
  secondaryIcon,
  tertiaryValue,
  tertiaryTitle,
  tertiaryIcon,
}) => (
  <Card
    elevation={0}
    sx={{
      height: '100%',
      borderRadius: 1,
      border: 1,
      borderColor: 'divider',
      bgcolor: 'background.paper',
      transition: 'border-color 0.2s ease',
      '&:hover': {
        borderColor: `${color}.main`,
      },
    }}
  >
    <CardContent sx={{ py: { xs: 1.5, sm: 2 }, px: { xs: 1.5, sm: 2 } }}>
      <Stack spacing={{ xs: 0.5, sm: 1 }}>
        {/* Mobile: Horizontal layout, Desktop: Vertical layout */}
        <Stack
          direction={{ xs: 'row', sm: 'column' }}
          spacing={{ xs: 1.5, sm: 1 }}
          sx={{
            justifyContent: { xs: 'space-between', sm: 'flex-start' },
            alignItems: { xs: 'center', sm: 'stretch' },
          }}
        >
          <MetricItem icon={icon} value={value} title={title} color={color} />

          {secondaryValue && secondaryIcon && (
            <MetricItem
              icon={secondaryIcon}
              value={secondaryValue}
              title={secondaryTitle}
              color={color}
            />
          )}
        </Stack>

        {tertiaryValue && tertiaryIcon && (
          <MetricItem
            icon={tertiaryIcon}
            value={tertiaryValue}
            title={tertiaryTitle}
            color={color}
          />
        )}

        {/* Subtitle */}
        {subtitle && (
          <Typography
            variant="caption"
            sx={{
              color: 'text.secondary',
              textAlign: 'center',
              mt: 1,
            }}
          >
            {subtitle}
          </Typography>
        )}

        {/* Trend */}
        {trend && (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 1 }}>
            <Chip
              label={trend}
              size="small"
              color={trend.startsWith('+') ? 'secondary' : 'default'}
              variant="outlined"
              sx={{ borderRadius: 2 }}
            />
          </Box>
        )}
      </Stack>
    </CardContent>
  </Card>
);

interface VenueData {
  name: string;
  count: number;
}

interface TopVenuesCardProps {
  venues: VenueData[];
}

const TopVenuesCard: React.FC<TopVenuesCardProps> = ({ venues }) => {
  const maxCount = venues.length > 0 ? venues[0]?.count || 1 : 1;

  return (
    <Card
      elevation={0}
      sx={{
        height: '100%',
        borderRadius: 1,
        border: 1,
        borderColor: 'divider',
        bgcolor: 'background.paper',
        transition: 'border-color 0.2s ease',
        '&:hover': {
          borderColor: 'secondary.main',
        },
      }}
    >
      <CardContent
        sx={{
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          py: { xs: 1.5, sm: 2 },
          px: { xs: 1.5, sm: 2 },
        }}
      >
        <Typography
          variant="h6"
          gutterBottom
          sx={{
            fontWeight: 'bold',
            fontSize: { xs: '0.9rem', sm: '1.25rem' },
            mb: { xs: 0.75, sm: 1.5 },
            flexShrink: 0,
          }}
        >
          Top Venues
        </Typography>
        <Box
          sx={{
            flex: 1,
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'space-around',
            position: 'relative',
            minHeight: { xs: '80px', sm: '110px' },
            px: { xs: 0.5, sm: 1 },
            pb: { xs: 1.5, sm: 2 },
            pt: { xs: 1.5, sm: 2 },
          }}
        >
          {venues?.map(venue => (
            <Box
              key={venue.name}
              sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                flex: 1,
                mx: { xs: 0.2, sm: 0.4 },
                height: '100%',
                position: 'relative',
                justifyContent: 'flex-end',
              }}
            >
              {/* Count label positioned at top */}
              <Typography
                variant="caption"
                sx={{
                  position: 'absolute',
                  top: { xs: -16, sm: -20 },
                  color: 'text.secondary',
                  fontSize: { xs: '0.55rem', sm: '0.65rem' },
                  fontWeight: 'medium',
                  whiteSpace: 'nowrap',
                }}
              >
                {venue.count}
              </Typography>

              {/* Bar - proportional height based on data */}
              <Box
                sx={{
                  width: '100%',
                  maxWidth: { xs: '28px', sm: '44px' },
                  height: {
                    xs: `${Math.max((venue.count / maxCount) * 45, 4)}px`,
                    sm: `${Math.max((venue.count / maxCount) * 65, 6)}px`,
                  },
                  backgroundColor: theme => theme.palette.secondary.main,
                  borderRadius: '3px 3px 0 0',
                  transition: 'background-color 0.2s ease, transform 0.2s ease',
                  cursor: 'pointer',
                  '&:hover': {
                    backgroundColor: theme => theme.palette.secondary.dark,
                    transform: 'scaleY(1.04)',
                    transformOrigin: 'bottom',
                  },
                }}
              />

              {/* Venue label positioned at bottom */}
              <Typography
                variant="body2"
                sx={{
                  position: 'absolute',
                  bottom: { xs: -16, sm: -20 },
                  fontSize: { xs: '0.55rem', sm: '0.65rem' },
                  fontWeight: 'medium',
                  color: 'text.secondary',
                  textAlign: 'center',
                  whiteSpace: 'nowrap',
                  maxWidth: { xs: '35px', sm: '50px' },
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                }}
              >
                {venue.name}
              </Typography>
            </Box>
          ))}
        </Box>
      </CardContent>
    </Card>
  );
};

interface YearDistributionChartProps {
  yearData: Record<string, number>;
}

const YearDistributionChart: React.FC<YearDistributionChartProps> = ({
  yearData,
}) => {
  const maxCount = Math.max(
    ...Object.values(yearData).filter((v): v is number => v !== undefined)
  );
  const years = Object.keys(yearData).sort((a, b) => parseInt(a) - parseInt(b));

  return (
    <Card
      elevation={0}
      sx={{
        height: '100%',
        borderRadius: 1,
        border: 1,
        borderColor: 'divider',
        bgcolor: 'background.paper',
        transition: 'border-color 0.2s ease',
        '&:hover': {
          borderColor: 'primary.main',
        },
      }}
    >
      <CardContent
        sx={{
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          py: { xs: 1.5, sm: 2 },
          px: { xs: 1.5, sm: 2 },
          overflow: 'hidden',
        }}
      >
        <Typography
          variant="h6"
          gutterBottom
          sx={{
            fontWeight: 'bold',
            fontSize: { xs: '0.9rem', sm: '1.25rem' },
            mb: { xs: 0.75, sm: 1.5 },
            flexShrink: 0,
          }}
        >
          Paper Distribution by Year
        </Typography>
        <Box
          sx={{
            flex: 1,
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'space-around',
            position: 'relative',
            minHeight: { xs: '80px', sm: '110px' },
            px: { xs: 0.5, sm: 1 },
            pb: { xs: 1.5, sm: 2 },
            pt: { xs: 1.5, sm: 2 },
          }}
        >
          {years.map(year => (
            <Box
              key={year}
              sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                flex: 1,
                mx: { xs: 0.2, sm: 0.5 },
                height: '100%',
                position: 'relative',
                justifyContent: 'flex-end',
              }}
            >
              {/* Count label positioned at top */}
              <Typography
                variant="caption"
                sx={{
                  position: 'absolute',
                  top: { xs: -16, sm: -20 },
                  color: 'text.secondary',
                  fontSize: { xs: '0.55rem', sm: '0.65rem' },
                  fontWeight: 'medium',
                  whiteSpace: 'nowrap',
                }}
              >
                {yearData[year]}
              </Typography>

              {/* Bar - proportional height based on data */}
              <Box
                sx={{
                  width: '100%',
                  maxWidth: { xs: '14px', sm: '20px' },
                  height: {
                    xs: `${Math.max(((yearData[year] || 0) / maxCount) * 45, 4)}px`,
                    sm: `${Math.max(((yearData[year] || 0) / maxCount) * 65, 6)}px`,
                  },
                  backgroundColor: theme => theme.palette.primary.main,
                  borderRadius: '3px 3px 0 0',
                  transition: 'background-color 0.2s ease, transform 0.2s ease',
                  cursor: 'pointer',
                  '&:hover': {
                    backgroundColor: theme => theme.palette.primary.dark,
                    transform: 'scaleY(1.04)',
                    transformOrigin: 'bottom',
                  },
                }}
              />

              {/* Year label positioned at bottom */}
              <Typography
                variant="body2"
                sx={{
                  position: 'absolute',
                  bottom: { xs: -16, sm: -20 },
                  fontSize: { xs: '0.6rem', sm: '0.7rem' },
                  fontWeight: 'medium',
                  color: 'text.secondary',
                  textAlign: 'center',
                  whiteSpace: 'nowrap',
                }}
              >
                &apos;{year.toString().slice(-2)}
              </Typography>
            </Box>
          ))}
        </Box>
      </CardContent>
    </Card>
  );
};

interface StatsDashboardProps {
  data: Paper[];
}

const StatsDashboard: React.FC<StatsDashboardProps> = ({ data }) => {
  const {
    totalPapers,
    totalAuthors,
    totalVenues,
    yearDistribution,
    venueStats,
  } = useMemo(() => calculateStats(data), [data]);

  return (
    <Box sx={{ mb: { xs: 0.5, sm: 0.75 } }}>
      <Grid container spacing={{ xs: 1.5, sm: 2 }}>
        {/* Compact Total Papers & Authors & Venues */}
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <StatCard
            title="Papers"
            value={totalPapers}
            secondaryValue={totalAuthors}
            secondaryTitle="Authors"
            tertiaryValue={totalVenues}
            tertiaryTitle="Venues/Journals"
            icon={School}
            secondaryIcon={People}
            tertiaryIcon={Business}
            color="primary"
          />
        </Grid>

        {/* Year Distribution Chart */}
        <Grid size={{ xs: 12, sm: 6, md: 4 }}>
          <YearDistributionChart yearData={yearDistribution} />
        </Grid>

        {/* Compact Top Venues */}
        <Grid size={{ xs: 12, md: 5 }}>
          <TopVenuesCard venues={venueStats} />
        </Grid>
      </Grid>
    </Box>
  );
};

export default StatsDashboard;
