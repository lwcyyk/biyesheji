# B1文件级维护申请

## Material Passport

DCL-R6-B1-ApprovalGate，B1-ApprovalGate/review-1，2026-11-16，Asia/Shanghai。本阶段完成合同、语义差异规划与实施准入审查。证据为冻结源码/输入、既有证明和两项分开执行的只读源审查。

**范围审查PASS_STATIC，实施准入B1_BLOCKED_BY_CLOSE_RESERVE。** 行为候选为c09_handoff.py和guard.py。manager_recovery.py列为必须核验的接口依赖，涉及MR关闭责任变化时需新增明确申请。以下全部摘要直接取自已核对的ra01文件。[B1_FILE_PLAN.json](D:/毕业设计/research_main_innovation/decentralized_credential_lifecycle/DCL-R6-B1-ApprovalGate/evidence/B1_FILE_PLAN.json) [FUNCTION_SOURCE_INDEX.json](D:/毕业设计/research_main_innovation/decentralized_credential_lifecycle/DCL-R6-B1-ApprovalGate/evidence/FUNCTION_SOURCE_INDEX.json)

### src/c09_handoff.py

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\src\c09_handoff.py|
|current_hash|0441874d3eec62720b920a48077bc52f4f3db9c64e3c21f3aa3aa97cd43e109f|
|category|FUTURE_MINIMUM_BEHAVIORAL_CANDIDATE|
|affected_function|lifecycle_lock:40, event:75, publish:85, sender_prepare:168, Receiver.poll:205, Receiver.observe_exit:252, resume_admission:323|
|issue|PENDING反复append，全部三event调用与六stage必须共用额度不变量|
|proposed_delta|独立cursor绑定/七类别位/持久预扣与completion/终态锁存/封闭schema，额外policy和ordinal放cursor，耗尽消费沿现有异常关闭链请求|
|invariant|当前main/window编码、ACK/commit/witness、安全谓词classify、原预算快照与一次resume语义作为保持式|
|regression|BQ01, BQ02, BQ03, BQ04, BQ05, BQ07, BQ08, BQ09, BQ10, BQ15|
|dependency|guard调用者与预付, BC.Store私有JSON, c09_contract和新quota输入, B-C6关闭子合同|
|rollback|将来隔离候选可整体弃用，授权前源摘要可复核，已消费预算/已有终态保留为原件|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/src/c09_handoff.py)
### src/guard.py

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\src\guard.py|
|current_hash|30a8443ded71e02325362f16eb2cc3547153f34426a7975dd9e9762b42fbc099|
|category|FUTURE_MINIMUM_BEHAVIORAL_CANDIDATE|
|affected_function|authorization:232, c09_contract:334, _external_stop_impl:771, external_stop:813, _launcher_work:1028|
|issue|原caller只消费VERIFIED/CLOSED，新的耗尽返回值会落回循环，scalar预付依赖正确ticket和时点|
|proposed_delta|在1095后与1096前绑定有效C00票据并256次scalar预付，恢复_TICKET，加载并核验新quota契约，明确耗尽异常从H锁释放后到808/817既有abort责任|
|invariant|630-691预算核心、真实CLOSED含义、counter固定后R稳定、资格门和所有既有期限作为保持式|
|regression|BQ02, BQ06, BQ09, BQ11, BQ12, BQ13, BQ14|
|dependency|c09_handoff, current C00 ticket, source/input/authorization锁, M.abort接口|
|rollback|隔离候选source/输入/锁按同一版本撤回，现行运行目录和已关闭实例保持审计来源|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/src/guard.py)
### src/manager_recovery.py

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\src\manager_recovery.py|
|current_hash|8423817dbaac4c62597cfd3f86a9fcc3096df1d1bfaa3411645d869642eb4600|
|category|INTERFACE_REVIEW_REQUIRED_CHANGE_NOT_SELECTED|
|affected_function|abort:317, _stop_other_roots:291, permit_external_seal:405, seal:414, prepay:453|
|issue|耗尽经两层abort并生产首错、STOP/CLOSED、attempt/state等独立证据，必要关闭空间未证明|
|proposed_delta|本次文件级计划仅核对接口、双层调用次数、错误/UNKNOWN和锁序，改变MR关闭责任须追加明确文件和合同审批|
|invariant|首错语义、原预算/期限、真实pidfd/组空、单sealer和跨实例规则作为依赖保持式|
|regression|BQ11, BQ12, BQ13, BQ15|
|dependency|B-C6, guard异常链, RootIPC, BC.Store|
|rollback|待审申请未选定MR行为修改，后续独立diff需要独立回退版本|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/src/manager_recovery.py)
### src/boot_continuity.py

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\src\boot_continuity.py|
|current_hash|9b8fc8011742043bf84974c7eef331ff225ad9c442a44988e8a4a4e7df2b65b2|
|category|EXISTING_HELPER_READ_DEPENDENCY|
|affected_function|Store.read:78, Store.put:86, entry:415|
|issue|私有JSON发布可复用，但输入quota控制与残留staging消费由调用者承担|
|proposed_delta|使用现有私有.json路径语义审查cursor和首错存储，完整大小验证和单次失败责任在拟B1调用层说明|
|invariant|Root权限、metadata、file/directory fsync、单次activation/resume保持式|
|regression|BQ07, BQ08, BQ10|
|dependency|RootIPC目录链, quota schema|
|rollback|只读依赖版本锁|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/src/boot_continuity.py)
### src/root_ipc.py

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\src\root_ipc.py|
|current_hash|567d45ddcb8e7b42b08192d8ba80d484723cb9b12248a7c23ba16f181e24f849|
|category|EXISTING_HELPER_READ_DEPENDENCY|
|affected_function|policy:21, publish:91, checkpoint:143|
|issue|关闭marker使用新增staging且共享storage，可信来源与空间保证需分别核验|
|proposed_delta|核对现行STOP/CLOSED目标与取消支配性，选择BC.Store私有域后无需新增RootIPC目标|
|invariant|可信权限/无链接发布/取消支配/跨目录fsync作为保持式|
|regression|BQ08, BQ09, BQ13|
|dependency|B-C6|
|rollback|只读依赖版本锁|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/src/root_ipc.py)
### src/c09_regression.py

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\src\c09_regression.py|
|current_hash|aa28e9f8c8d53b6780bc727f7a678d3c3bf08332c25b582cfbf7aa57b6546a8f|
|category|EXISTING_SYNTHETIC_REFERENCE|
|affected_function|Subject.step:10, run_suite:52|
|issue|H34合成classify轨迹缺原生日志quota I/O覆盖|
|proposed_delta|用于回归语义基线，新增quota检查另列review_only计划|
|invariant|H1-H8原定义和已冻结34 jobs|
|regression|BQ14, BQ15|
|dependency|c09_oracle.py|
|rollback|原合成基线持续作为读取输入|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/src/c09_regression.py)
### src/c09_oracle.py

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\src\c09_oracle.py|
|current_hash|7770f85435089af3e2cb0bda28ba9e759ba6624b3f766ce1823514b788e126da|
|category|EXISTING_SYNTHETIC_REFERENCE|
|affected_function|check_job:41, check_suite:79|
|issue|既有oracle验证合成truth和收费，主log/cursor新原件需独立计划|
|proposed_delta|原函数作为保持式，新quota oracle在独立review_only路径提出|
|invariant|独立H1-H8判断和原始事件集合/计费检查|
|regression|BQ15|
|dependency|new oracle plan|
|rollback|原oracle版本锁|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/src/c09_oracle.py)
### inputs/c09_contract.json

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\inputs\c09_contract.json|
|current_hash|601dc8eaaecaa98189c3a03524c023d924fade37fe458402f1b5335de66ca68c|
|category|FUTURE_INPUT_BINDING_CANDIDATE|
|affected_function|JSON bound fields|
|issue|需绑定quota profile与测试范围|
|proposed_delta|仅提出新版本quota引用/作用域/字节profile字段|
|invariant|版本完整性与授权来源|
|regression|BQ01, BQ10, BQ14, BQ15|
|dependency|source_manifest, quota_contract|
|rollback|候选输入与对应source/lock整组弃用，历史原件保持|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/inputs/c09_contract.json)
### inputs/static_manifest.json

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\inputs\static_manifest.json|
|current_hash|738eb2982953971f94019b913f6b302808f9b7a8d29e784038e8e6babb50de89|
|category|FUTURE_INPUT_BINDING_CANDIDATE|
|affected_function|JSON bound fields|
|issue|源码和输入内容摘要改变时需绑定|
|proposed_delta|source_hashes/bound_inputs与新quota输入摘要的独立重冻结|
|invariant|版本完整性与授权来源|
|regression|BQ01, BQ10, BQ14, BQ15|
|dependency|source_manifest, quota_contract|
|rollback|候选输入与对应source/lock整组弃用，历史原件保持|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/inputs/static_manifest.json)
### inputs/execution_lock.json

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\inputs\execution_lock.json|
|current_hash|691f2503f2db6906552241692db0b27ec6a982a7c738839d99f3cd93f3729da6|
|category|FUTURE_INPUT_BINDING_CANDIDATE|
|affected_function|JSON bound fields|
|issue|manifest与quota契约需要精确绑定|
|proposed_delta|未来只在静态review lock固定新manifest/契约摘要，运行身份和授权另行审批|
|invariant|版本完整性与授权来源|
|regression|BQ01, BQ10, BQ14, BQ15|
|dependency|source_manifest, quota_contract|
|rollback|候选输入与对应source/lock整组弃用，历史原件保持|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/inputs/execution_lock.json)
### inputs/manager_contract.json

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\inputs\manager_contract.json|
|current_hash|914bd447f7f7183a82f43d4a60ffbbaf780308b6cd3e53ced0c101d8b91ac7bf|
|category|READ_ONLY_BOUNDARY_DEPENDENCY|
|affected_function|frozen file|
|issue|当前MR接口读取依赖，MR行为差异尚未选定|
|proposed_delta|仅核对绑定及当前责任|
|invariant|原始证据/资格/权限和范围保持式|
|regression|BQ14, BQ15|
|dependency|full capacity|
|rollback|只读依赖版本锁|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/inputs/manager_contract.json)
### inputs/batch_identity.json

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\inputs\batch_identity.json|
|current_hash|3ceee4092ba1f5dbe467cdc35110c4a3f3297feb31e707ae2a3cd15f74aa0ee2|
|category|READ_ONLY_BOUNDARY_DEPENDENCY|
|affected_function|frozen file|
|issue|当前旧namespace读取依赖，新运行身份须后续明确授权|
|proposed_delta|仅核对绑定及当前责任|
|invariant|原始证据/资格/权限和范围保持式|
|regression|BQ14, BQ15|
|dependency|full capacity|
|rollback|只读依赖版本锁|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/inputs/batch_identity.json)
### inputs/runtime_tree_lock.json

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\inputs\runtime_tree_lock.json|
|current_hash|77119f18c9c8ef491ced95c1e9f4f06cc70bf3be9cb1d91a7bfdafb3fb65d67d|
|category|READ_ONLY_BOUNDARY_DEPENDENCY|
|affected_function|frozen file|
|issue|绑定Python标准库树，B1同运行时假设下作为只读TCB依赖|
|proposed_delta|仅核对绑定及当前责任|
|invariant|原始证据/资格/权限和范围保持式|
|regression|BQ14, BQ15|
|dependency|full capacity|
|rollback|只读依赖版本锁|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/inputs/runtime_tree_lock.json)
### src/terminal_evidence.py

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\src\terminal_evidence.py|
|current_hash|97569f2f2a3596b58458b8ea5062478cee4a519ac2092ff8868c9b859b82c710|
|category|READ_ONLY_BOUNDARY_DEPENDENCY|
|affected_function|frozen file|
|issue|终态/归档读取门的后层依赖|
|proposed_delta|仅核对绑定及当前责任|
|invariant|原始证据/资格/权限和范围保持式|
|regression|BQ14, BQ15|
|dependency|full capacity|
|rollback|只读依赖版本锁|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/src/terminal_evidence.py)
### src/startup_lifecycle.py

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\src\startup_lifecycle.py|
|current_hash|97428345ec242ad88ea0569fff05be76515d88e496925d8a2920af9b18dfb362|
|category|READ_ONLY_BOUNDARY_DEPENDENCY|
|affected_function|frozen file|
|issue|行政导出与原256守卫后层依赖|
|proposed_delta|仅核对绑定及当前责任|
|invariant|原始证据/资格/权限和范围保持式|
|regression|BQ14, BQ15|
|dependency|full capacity|
|rollback|只读依赖版本锁|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/src/startup_lifecycle.py)
### host/startup_finalize.py

|项目|内容|
|---|---|
|file|D:\毕业设计\DCL-R6-isolated-verification\ra01\host\startup_finalize.py|
|current_hash|9b233006140fa0b8354b8729bc992425cbd0e5077bad8724358fd61593cb8153|
|category|READ_ONLY_BOUNDARY_DEPENDENCY|
|affected_function|frozen file|
|issue|host封存/原始流后层依赖|
|proposed_delta|仅核对绑定及当前责任|
|invariant|原始证据/资格/权限和范围保持式|
|regression|BQ14, BQ15|
|dependency|full capacity|
|rollback|只读依赖版本锁|

[原文件](D:/毕业设计/DCL-R6-isolated-verification/ra01/host/startup_finalize.py)


### 拟新增文件位置

建议的独立静态评审目录为D:\毕业设计\research_main_innovation\decentralized_credential_lifecycle\DCL-R6-B1-Maintenance-Review-PROPOSED。目录名由本轮规划提出，采纳决定由用户作出。该目录与下列五个对象当前均为PROPOSED_ABSENT。完整十属性表记录在未来文件清单。[FUTURE_FILE_SLOTS.json](D:/毕业设计/research_main_innovation/decentralized_credential_lifecycle/DCL-R6-B1-ApprovalGate/evidence/FUTURE_FILE_SLOTS.json)

|拟议绝对路径|用途|当前状态|
|---|---|---|
|D:\毕业设计\research_main_innovation\decentralized_credential_lifecycle\DCL-R6-B1-Maintenance-Review-PROPOSED\inputs\c09_quota_contract.json|quota固定schema、上限、绑定、失败/终态及生效前提|PROPOSED_ABSENT，current_hash=null|
|D:\毕业设计\research_main_innovation\decentralized_credential_lifecycle\DCL-R6-B1-Maintenance-Review-PROPOSED\review_only\B1_TEST_CASES.json|15项negative/边界义务的纯数据清单|PROPOSED_ABSENT，current_hash=null|
|D:\毕业设计\research_main_innovation\decentralized_credential_lifecycle\DCL-R6-B1-Maintenance-Review-PROPOSED\review_only\b1_quota_checks.py|未来经批准的独立静态/隔离harness|PROPOSED_ABSENT，current_hash=null|
|D:\毕业设计\research_main_innovation\decentralized_credential_lifecycle\DCL-R6-B1-Maintenance-Review-PROPOSED\review_only\b1_quota_oracle.py|未来经批准的独立raw重算oracle|PROPOSED_ABSENT，current_hash=null|
|D:\毕业设计\research_main_innovation\decentralized_credential_lifecycle\DCL-R6-B1-Maintenance-Review-PROPOSED\review_only\B1_STATIC_REVIEW_LOCK.json|未来候选源码、输入、测试清单和独立oracle的准确摘要锁|PROPOSED_ABSENT，current_hash=null|

runtime_tree_lock的files绑定/usr/lib/python3.12标准库树，应用源码条目数为0。当前最小维护将其列为只读TCB依赖。准确需重冻结的绑定是source_hashes、bound_inputs、新quota输入、c09契约及对应静态审查锁。新运行namespace与执行身份属于后续独立申请。[BINDING_SCOPE_REFINEMENTS.json](D:/毕业设计/research_main_innovation/decentralized_credential_lifecycle/DCL-R6-B1-ApprovalGate/evidence/BINDING_SCOPE_REFINEMENTS.json)

回退适用于未来尚未执行的独立候选及其引用。若将来已经产生执行事实，该实例的原预算、T0、终态和全部原始证据永久保留，源码回退也须采用新的身份/锁。当前rollback字段属于计划。[待批维护请求](D:/毕业设计/research_main_innovation/decentralized_credential_lifecycle/DCL-R6-B1-ApprovalGate/proposals/B1_MAINTENANCE_REQUEST_DRAFT.json)


RESOURCE_GATE_PASS=NOT_OBTAINED

F1=UNRUN_RESOURCE_GATE，F4=UNRUN_RESOURCE_GATE

MR_CROSS_INSTANCE_ADMISSION=PROPOSED_NOT_EFFECTIVE

STRICT_SEPARATION_INSTANCES=0，PASS_BOUNDED=[]，IMPLEMENTATION_GATE=CLOSED。
