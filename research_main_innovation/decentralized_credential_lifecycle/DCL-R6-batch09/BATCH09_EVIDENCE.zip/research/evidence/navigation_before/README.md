# DCL-R6-batch08-Diag 最新最小诊断裁决（2026-11-12）

PREFLIGHT_PASS / SAME_BOOT_CONFIRMED / C00_PASS：C00Ready-static-1/r2实际单会话启动，Root438/start4792跨exec；C00自查811/start4978同boot0cc7ff50…。真实1轮STARTING后2轮READY，首次凭据CR01–05 defer为NOT_READY，最终8项双侧全MATCH。wait返回区间0.149840881–0.155141782秒；精确pidfd/返回点未单独打点，D08-4总体FIELD_EVIDENCE_PARTIAL。

64项获准合成检查全部接受：47 PASS＋17 MUTATION_DETECTED，独立reference无差异。R450/450持久事务/900行配对；T0后10.267560352秒按C00_DIAGNOSTIC_COMPLETE正常关闭，进程/父组为空，原生100条目seal保存。源码/权限修复、重跑/恢复0，batch09创建0。

Full批准false，其余BC40/RootIPC56/C09H34/C01–C12/C09/S34/门17及F1/F4均未授权/未运行，RESOURCE_GATE_PASS仍NOT_OBTAINED。旧batch07具体失败字段保持UNRESOLVED；下一步可准备匹配新批次版本/锁的独立完整链，不恢复已CLOSED的batch08。D1-PBFT-SEAL/1.1原条件、强G覆盖、严格分离0、IMPLEMENTATION_GATE=CLOSED保持。

[最终裁决](DCL-R6-batch08-Diag/BATCH08_DIAG_FINAL_DECISION.md) · [字段证据](DCL-R6-batch08-Diag/BATCH08_C00_FIELD_RESULTS.md) · [证据索引](DCL-R6-batch08-Diag/EVIDENCE_INDEX.md)

以下完整保存本轮前历史导航，旧阶段许可/下一步/未创建文字按相应时点理解。

---

# DCL-R6-C00Ready-Fix 最新静态裁决（2026-11-11）

C00Ready-static-1/r2在host冻结：原真实8项逐字段审计/诊断、exec-ready三态与14秒同窗口屏障、双次采样/pidfd/native lease、C00/C10票据前复查；具体batch07失败字段仍C00_FAILED_FIELD_UNRESOLVED。原sealed/一次认领/exec与RootIPC/C09逻辑保持，15旧程序字节和24预算/资格函数AST保持。

CR-1/CR-4=PASS_STATIC，CR-2/CR-3=CONDITIONAL_PASS。64夹具/17mutant、24程序host语法/3.12文法和36项锁完成；native部署/查询/服务/测试/batch08创建0。最小C00_DIAGNOSTIC_ONLY完成后关闭，完整C/S/H/门/F1F4另需明确批准；新增449/512访问，完整cal硬上界62546≤100000，原300/1800及总1e6不扩。

batch07同PID/boot启动前缀、R0及原失败原件保持；旧预算/历史/误副本/blocked by policy保持。D1-PBFT-SEAL/1.1原条件、强G覆盖、严格分离0、IMPLEMENTATION_GATE=CLOSED保持。

[最终裁决](DCL-R6-C00Ready-Fix/FINAL_DECISION.md) · [batch08申请](DCL-R6-C00Ready-Fix/BATCH08_EXECUTION_REQUEST.md) · [证据索引](DCL-R6-C00Ready-Fix/EVIDENCE_INDEX.md)

以下为本轮前完整保存的历史导航，各旧阶段许可/下一步/未创建文字按相应时点理解。

---

# DCL-R6-batch07 最新实际裁决（2026-11-11）

RESOURCE_GATE_FAILED：BootContinuity-static-1/r4已实际单会话预检、sealed fd/一次认领、same-PID exec到Guard；活动boot060a08fc…、父PID828/start7252贯穿前缀。C00票据前服务复核抛BC_SERVICE_IDENTITY_OR_LIMITS，BOOT_START未发布；具体8路失配字段无快照，源码MainPID>0缺exec-ready屏障与Starting-only journal支持启动临态竞态假设。

T0=73.768774900，R0/1000000；T0+0.309347559闭合、+0.327163166组空，普通父waitpid raw32000/exit125。原生22条目seal、23 native文件、32冻结文件、34事件/15内部命令及7条run journal封存；source/权限修复、case重试、resume与batch08创建均0。BC40、RootIPC56、C09H34、真实C09、C01–C12、S34/门17及F1/F4都未完成准入；PASS_BOUNDED授予0。

下一步仅列有界exec-ready/稳定身份屏障及完整失败采样的最小静态修复方向，保持原身份/AS/ACK/停止断言。D1-PBFT-SEAL/1.1原条件、强G覆盖、严格分离0、IMPLEMENTATION_GATE=CLOSED保持。

[batch07最终裁决](DCL-R6-batch07/BATCH07_FINAL_DECISION.md) · [首次失败](DCL-R6-batch07/BATCH07_COUNTEREXAMPLES.md) · [证据索引](DCL-R6-batch07/EVIDENCE_INDEX.md)

以下为本轮启动前完整保留的历史导航，各旧阶段资格/许可/下一步按对应时点理解。

---

# DCL-R6-BootContinuity-Fix 最新静态裁决（2026-11-11）

BootContinuity-static-1/r4已在host冻结：单次WSL受信入口、same-PID exec与封印fd/持久一次认领、Root/服务内fresh复查、同一Root进程C09一次恢复；原14份程序字节与24预算/资格函数AST保持。新增40模拟回归/10变异，21程序host语法及3.12文法通过，32项包无旧pyc。

BC-1/BC-2/BC-4=PASS_STATIC；BC-3=CONDITIONAL_PASS。目标3.12原生编译、当前WSL/接口、真实启动及测试全部UNRUN；本轮新WSL调用/部署/服务/T0/账/batch07创建均为0。新许可须明确source-only、预检TCB120秒/AS1GiB、初始10秒ticket与同进程恢复；BC481与既有合计3231≤5000，运行1800/校准300及原硬额保持。

batch06的三boot/109.295102秒/PREFLIGHT_FAILED与目标启动0保持；具体触发源BOOT_CHANGE_CAUSE_UNRESOLVED。D1-PBFT-SEAL/1.1原条件、强G覆盖、严格分离0、IMPLEMENTATION_GATE=CLOSED保持。

[最终裁决](DCL-R6-BootContinuity-Fix/FINAL_DECISION.md) · [batch07申请](DCL-R6-BootContinuity-Fix/BATCH07_EXECUTION_REQUEST.md) · [证据索引](DCL-R6-BootContinuity-Fix/EVIDENCE_INDEX.md)

以下完整保留本轮之前历史导航；旧阶段许可/下一步/未创建文字按各自记录时点理解。

---

# DCL-R6-batch06 最新裁决（2026-11-11）

PREFLIGHT_FAILED / RESOURCE_GATE_FAILED_PREFLIGHT：RootIPC-static-1/r4基础hash/runtime/身份预检通过，六条冻结准备和授权安装完成；最终启动前boot由3f63d905…变为c92b8cbc…，same_boot检查失败，按首次失败规则停止。Launcher/模型启动0，T0/预算账未建立；56项RootIPC、34项C09H、C00–C12、S34、门17与F1/F4全部未运行。

事后boot为b69460ad…，专用进程与父cgroup为空；out/private空，仅两份授权文件和44项实际Linux冻结源封存。具体WSL生命周期触发源待确认；后续先收敛同boot预检与入口交接的行政编排，当前重试/恢复/代码修复0、batch07创建0。

batch05的RESOURCE_GATE_FAILED、R37293及原失败保持；D1-PBFT-SEAL/1.1原条件、强G覆盖、严格分离0和IMPLEMENTATION_GATE=CLOSED保持。

[batch06最终裁决](DCL-R6-batch06/BATCH06_FINAL_DECISION.md) · [首次失败](DCL-R6-batch06/BATCH06_COUNTEREXAMPLES.md) · [证据索引](DCL-R6-batch06/EVIDENCE_INDEX.md)

以下为本轮开始前完整保留的历史导航，各旧阶段许可/未创建/下一步文字按其记录时点理解。

---

# DCL-R6-RootIPC-Fix 最新静态裁决（2026-11-11）

RootIPC-static-1/r4完成有限静态修复：Root共享intent发布前固定999:989/0600，Root私有与payload可读收据分离；ready/RPC/父waitpid加入停止fresh-read及有限回收。修改原2份源码、新增3份；原12程序及24预算/资格函数保持，56专项夹具/8变异与最终44项文件冻结。

RI-1/RI-4=PASS_STATIC；RI-2/RI-3=CONDITIONAL_PASS。17份最终源码语法与44项host/Linuxhash通过；动态执行0，batch06未创建。下一动态申请绑定r4真实hash，并明确新增最多1个顺序降权探针TCB、完整C/C09H/IPC56/S/17门及资格后自动F1→F4。实际停止延迟和300秒可完成性仍待测量。

batch05原RESOURCE_GATE_FAILED、R37,293、303事务、真实C09 NOT_EXERCISED与全部失败证据保持。D1-PBFT-SEAL/1.1、强G原条件、严格分离0、IMPLEMENTATION_GATE=CLOSED保持。

[最终裁决](DCL-R6-RootIPC-Fix/FINAL_DECISION.md) · [batch06申请](DCL-R6-RootIPC-Fix/BATCH06_EXECUTION_REQUEST.md) · [证据索引](DCL-R6-RootIPC-Fix/EVIDENCE_INDEX.md)

以下完整保留本轮开始前的历史导航；各旧阶段“下一步/许可/未创建”文字按对应时点理解。

---

# DCL-R6-batch05 最新结果（2026-11-11）

实际RESOURCE_GATE_FAILED：C00–C08九项PASS；C09H34 accepted（28 PASS+6 MUTATION_DETECTED）；Root审查后intent变为root:root/0600，真实C09 uid999入口读取失败，持久ACK/交接退出见证尚未取得。预算37,293；payload在T0+20.927591657清空，Root约T0+300退出。C10–C12、S34、门17与F1/F4全部未运行；PASS_BOUNDED授予0。

当前batch05保持CLOSED；下一研究动作仅为审查共享账跨身份owner/mode与C09闭合等待的静态修复范围，审计全部Root全局记账路径，并在独立版本冻结后处理匹配动态许可。实现修改、权限修复、重试、恢复与batch06创建均为0。D1-PBFT-SEAL/1.1原条件、强G覆盖、严格分离0和IMPLEMENTATION_GATE=CLOSED保持；候选机制继续先过可证伪分离声明及严格实例门。

[batch05最终裁决](DCL-R6-batch05/BATCH05_FINAL_DECISION.md) · [首次失败](DCL-R6-batch05/BATCH05_COUNTEREXAMPLES.md) · [证据索引](DCL-R6-batch05/EVIDENCE_INDEX.md)

以下为本批启动前保留的历史记录；其中旧阶段“下一步/未授权/未创建”文字按其阶段理解。

---

# DCL-R6-C09Fix：静态修复与batch05申请

2026-11-11。[最终裁决](DCL-R6-C09Fix/FINAL_DECISION.md)、[H1/H2根因](DCL-R6-C09Fix/C09_ROOT_CAUSE_ANALYSIS.md)、[源码锁](DCL-R6-C09Fix/SOURCE_AND_INPUT_LOCK.md)、[新执行申请](DCL-R6-C09Fix/BATCH05_EXECUTION_REQUEST.md)。

已交付C09Fix-static-1/r1：持久接收ACK、父waitpid见证、pidfd后fresh-read、闭合锁及一次分类，新增34个C09H回归。10份原业务/runner/探针/range程序字节保持；14源语法通过。根因区分旧快照与未完成交接，原batch04缺成功收据的事实保留。

本轮动态执行0，RESOURCE_GATE_PASS=NOT_OBTAINED，F1/F4=UNRUN_RESOURCE_GATE，batch05未授权/未创建。新增C09H硬限5000，完整cal硬界62034≤100000，仍300秒；新增可信root行政协调器1进程须下一许可明确接受。主机制门CLOSED、严格分离0。以下为历史导航。

---

# DCL-R6-batch04：C02修复生效，C09首次失败关闭

2026-11-11。[最终裁决](DCL-R6-batch04/BATCH04_FINAL_DECISION.md)、[C02性能](DCL-R6-batch04/BATCH04_C02_PERFORMANCE.md)、[监督器缺陷](DCL-R6-batch04/BATCH04_COUNTEREXAMPLES.md)、[证据索引](DCL-R6-batch04/EVIDENCE_INDEX.md)。

预检及C00–C08实际通过。C02单笔预留32896，核心27.617904ms，实际child17991操作，服务至结果2.932093220秒。C09预定exit23后，停止器使用早先快照误判UNEXPECTED_LAUNCHER_EXIT，T0+9.349857737秒关闭；组空已确认。恢复被CLOSED拒绝，未调用resume。

账37021/1000000、31事务完整，未用信用保留；S34/门17/F1/F4均未运行。RESOURCE_GATE_PASS=NOT_OBTAINED，下一步先修复具体C09竞态；源码/输入未改、无重跑或batch05。主机制门CLOSED、严格分离0保持。以下为历史导航。

---

# DCL-R6-GapClosure：BF-static-2/r4静态补缺完成

2026-11-11。[最终裁决](DCL-R6-GapClosure/FINAL_DECISION.md)、[源码与输入锁](DCL-R6-GapClosure/SOURCE_AND_INPUT_LOCK.md)、[下一执行申请](DCL-R6-GapClosure/NEXT_EXECUTION_AUTHORIZATION.md)、[证据索引](DCL-R6-GapClosure/EVIDENCE_INDEX.md)。

已交付真实公共范围核心、34个S1–S9正反job、独立原始检查器和17个门负向检查，强制接入C00–C12之后的资格链。原五业务、runner和探针字节不变；11源语法通过，源/输入/argv冻结于r4（命令封存修订1）。GC-1/GC-4=PASS_STATIC，GC-2/GC-3=CONDITIONAL_PASS。

本轮仅静态修复及检查。S/C校准与F1/F4执行0，RESOURCE_GATE_PASS=NOT_OBTAINED；新batch04未授权、未创建，T0/账未初始化。主机制门CLOSED、严格分离0保持。以下保留历史导航。

---

# DCL-R6-batch03：条件授权已收到，启动前证据门阻断

2026-11-11。[最终裁决](DCL-R6-batch03/BATCH03_FINAL_DECISION.md)、[授权与锁](DCL-R6-batch03/BATCH03_AUTHORIZATION_AND_LOCK.md)、[S1–S9能力表](DCL-R6-batch03/BATCH03_BUDGET_SAFETY_RESULTS.md)、[证据索引](DCL-R6-batch03/EVIDENCE_INDEX.md)。

BF-static-1及1266唯一Linux文件hash匹配，运行时身份合规。本次§5要求缺故障能力时保持资源门关闭，§6要求关键UNKNOWN排除；冻结版本缺精确范围专项测试及匹配准入门，完整launcher在启动前阻断。仅研究目录已创建；payload、C00–C12、F1/F4、账和窗口均未启动/初始化。

资源结果RESOURCE_EVIDENCE_INCOMPLETE；RESOURCE_GATE_PASS=NOT_OBTAINED；F1/F4=UNRUN_RESOURCE_GATE；batch03=AUTHORIZED_PREFLIGHT_BLOCKED。本次明确条件自动授权事实保留；新版本的最小静态补足范围见[后续范围](DCL-R6-batch03/BATCH03_GAP_CLOSURE_SCOPE.md)。主机制门CLOSED、严格分离0保持。以下为历史导航。

---

# DCL-R6-BudgetFix：BF-static-1已冻结

2026-11-11。[最终裁决](DCL-R6-BudgetFix/FINAL_DECISION.md)、[真实源码与输入锁](DCL-R6-BudgetFix/SOURCE_AND_INPUT_LOCK.md)、[独立batch03申请](DCL-R6-BudgetFix/BATCH03_EXECUTION_REQUEST.md)、[证据索引](DCL-R6-BudgetFix/EVIDENCE_INDEX.md)。

限定静态修复完成：guard.py与guard_probe.py变更，run_batch及五业务字节相同；最终语法编译通过。精确N范围预留与一次认领、局部前置扣减和计时修复已交付；BF-1/BF-4=CONDITIONAL_PASS，BF-2/BF-3=PASS_STATIC。动态故障、性能与资源资格保持未决。

RESOURCE_GATE_PASS=NOT_OBTAINED；F1/F4=UNRUN_RESOURCE_GATE；batch03=UNAUTHORIZED且未创建；IMPLEMENTATION_GATE=CLOSED；严格分离0。校准软300/100000、全批1000000/1800/1740及AS4合同保持。以下保留此前研究导航。

---

# 去中心化凭据生命周期：batch02-Perf 当前入口

2026-11-10。[静态裁决](DCL-R6-batch02-Perf/FINAL_DECISION.md)、[精确时间线](DCL-R6-batch02-Perf/PERF_EXECUTION_TIMELINE.md)、[预算成本](DCL-R6-batch02-Perf/PERF_PERSISTENCE_COST_ANALYSIS.md)、[最小修复](DCL-R6-batch02-Perf/PERF_REPAIR_OPTIONS.md)、[新申请](DCL-R6-batch02-Perf/BATCH03_AUTHORIZATION_REQUEST.md)。

直接核验batch02两个ZIP与原始hash。C00/C01到结果仅1.109秒；C02预付内部跨度298.626607199秒，占共同300秒软窗99.5422%，平均9.277864ms/混合周期。全部PREP/COMMIT复用同戳，单次fsync/锁/CPU份额仍UNKNOWN_INTERVAL，未把源码7同步计数当成实测时延。

32191=入口3＋未启动child预付32188；模型/内存子操作0。选择A0：冻结有界child精确N一次持久范围、一次委派，保持全部安全屏障和300秒软窗；C02事务数32896→1为静态计数，墙钟收益待测。普通模型visit暂不改。

PERF1/2 PASS_STATIC、PERF3 CONDITIONAL_PASS、PERF4 PARTIAL；当前只完成设计，未写修复/探针/配置，未新建lc03/batch03。副本47文件只读hash一致，未尝试任何被拒绝操作，未来输入仅用正确根。原C00/C01局部通过、C02失败、账/代码/历史/强G/零分离/协议1.1及主机制门CLOSED保持。以下保留历史。

---
# 去中心化凭据生命周期：DCL-R6-batch02 实际结果

2026-11-10。[本批裁决](DCL-R6-batch02/BATCH02_FINAL_DECISION.md)、[校准](DCL-R6-batch02/BATCH02_RESOURCE_CALIBRATION.md)、[资源账](DCL-R6-batch02/BATCH02_RESOURCE_ACCOUNTING.md)、[交付索引](DCL-R6-batch02/README.md)。

已按新专项许可执行冻结Launcher。C00/C01局部PASS，C02在300秒软截止到达时仍在持久预付，Controller信号9、原始FAIL，分析为INCONCLUSIVE_LIMIT_CAL_SOFT_TIME；allocator child未启动。C03–C12/五业务兼容/F1/F4未达，资源门未取得。

最终32191/1000000预留，PREPARED/COMMITTED各32191且连续完整，无模糊事务；T0+300.1698498秒关闭、外层exit65。父树/全部本批瞬态进程退出、无STOP_UNCONFIRMED；原ZIP及正确host快照核hash通过。batch02=CLOSED_RESOURCE_GATE_FAILED，无恢复/重试/新预算。

B02-1 PARTIAL、B02-2 FAIL、B02-3/4 UNRUN、B02-5 CONDITIONAL_PASS。正式模型访问0、无PASS_BOUNDED/协议反例；旧源码/账/各阶段/L-C保持，D1 1.1/D2/G覆盖/归档/严格分离0与主机制门CLOSED不变。行政误路径重复副本因自动审批拒绝迁移/删除而保留，正确封存已核验。以下为历史入口。

---
# 去中心化凭据生命周期：DCL-R6-LC 当前入口

2026-11-10。[LC裁决](DCL-R6-LC/LC_FINAL_DECISION.md)、[交付索引](DCL-R6-LC/README.md)、[资源代码差异](DCL-R6-LC/LC_LINUX_ADAPTER_DIFF.md)、[batch02独立申请](DCL-R6-LC/LC_BATCH02_AUTHORIZATION_REQUEST.md)。

CPY312-UBU24/1已批准用于静态部署。实际dcl-r6身份999/989、lc01工作区和两个inactive单位建立；八文件语法/单位verify通过，三资源程序完成Linux静态接入，五业务文件保持原hash。实际AS/Tasks/权限属性读回与配置一致，MainPID0，无动态enforcement实例。

LC1–3 PASS_STATIC，LC4 CONDITIONAL_PASS。静态manifest、1224代码树/31关键文件、源/缓存/单位/输入及14组payload argv已冻结；C09唯一计划恢复保持同boot/T0/账，未知退出关闭。后续特殊映射/TCB/停止假设、真实C00–C12与语义检查仍需新许可和证据。

RESOURCE_GATE_PASS=NOT_OBTAINED、F1/F4=UNRUN_RESOURCE_GATE、batch02=UNAUTHORIZED；两端batch02未创建，out为空。未启动/enable验证service、未运行目标模块正文/探针/校准/模型。原27次/118.7340827秒/关闭deadline、v1/v2/v3及全部历史保持。主机制门CLOSED、严格分离0与D1 1.1/D2/G覆盖维持。以下为历史入口；旧根导航在LC/evidence/navigation_before。

---
# 去中心化凭据生命周期：DCL-R6-LR 当前入口

2026-11-10。[LR裁决](DCL-R6-LR/LR_FINAL_DECISION.md)、[交付索引](DCL-R6-LR/README.md)、[运行时路线](DCL-R6-LR/LR_RUNTIME_ROUTE_DECISION.md)、[L-C申请](DCL-R6-LR/LR_NEXT_AUTHORIZATION.md)。

已发现原生/usr/bin/python3.12，版本3.12.3、Ubuntu包3.12.3-1ubuntu0.17，默认python3指向它；ELF/摘要/直接库/关键标准库有据。五业务文件静态未见必须3.14的依赖，推荐L2的CPY312-UBU24/1候选，等待明确批准和后续独立验收。没有自动改用3.12或安装3.14。

LR-1/2 CONDITIONAL_PASS，LR-3 PARTIAL，LR-4 PASS_STATIC。manager255.4-1ubuntu8.18为degraded，失败清单仅mnt-e.mount；根memory/pids已启用但当前无限，专用dcl-r6用户/组和Linux活账目录缺失。L-C范围已具体化：新身份/工作区、inactive单位、资源三文件静态接入与语法/配置校验；当前未执行。

本轮35条Linux查询，Python仅一次--version；无资源/业务执行、代码、配置、安装、模型。L-C/batch02仍UNAUTHORIZED、RESOURCE_GATE_PASS=NOT_OBTAINED、F1/F4仍UNRUN_RESOURCE_GATE；原WS4 E2未决、主机制门CLOSED/严格分离0。原账27次/118.7340827秒及所有历史原件保持；旧根导航快照见DCL-R6-LR/evidence/navigation_before。下方保留历史入口。

---
# 去中心化凭据生命周期：DCL-R6-P 当前入口

2026-11-10。[P裁决](DCL-R6-P/P_FINAL_DECISION.md)、[交付索引](DCL-R6-P/README.md)、[原始命令](DCL-R6-P/evidence/P_COMMAND_RESULTS.json)、[L阶段需求](DCL-R6-P/P_NEXT_STAGE_REQUIREMENTS.md)。

P专项授权已完整执行12条固定WSL argv：11条exit0，两个指定Python3.14路径缺失导致第12条exit2。实际kernel6.18.33.2-microsoft-standard-WSL2/x86_64，PID1为systemd，工具255.4-1ubuntu8.18；cgroup2根memory/pids可用且启用；查询身份root。P1 PASS_STATIC、P2 CONDITIONAL_PASS、P3 FAIL、P4/P5 PARTIAL。

AS4-PAYLOAD/1仅原则接受用于平台审查；目标AS/pids限制、权限封闭、特殊映射、runtime与停止校准均待后续授权/证据。batch02=UNAUTHORIZED、RESOURCE_GATE_PASS=NOT_OBTAINED、F1/F4仍UNRUN_RESOURCE_GATE。下一步先补L的native runtime/身份/管理接口等只读缺项，再形成实际配置和执行锁。

没有额外Linux命令、主动停止、单位/资源配置、安装、探针、模型或验证代码。Ubuntu-24.04在查询期间运行，客户端退出后的即时状态未追加检查。batch01原账/版本/失败及Envelope原件保持；D1 1.1、D2条件结论、强G覆盖、I1/I2/I3归档、严格分离0及主机制门CLOSED维持。旧根导航快照见DCL-R6-P/evidence/navigation_before。以下保留历史入口。

---
# 去中心化凭据生命周期：DCL-R6-Envelope 当前入口

2026-11-10。[本轮裁决](DCL-R6-Envelope/FINAL_DECISION.md)、[九文档索引](DCL-R6-Envelope/README.md)、[严格界](DCL-R6-Envelope/STRICT_MEMORY_BOUND_PROOF.md)、[合同与授权申请](DCL-R6-Envelope/BATCH02_AUTHORIZATION_REQUEST.md)。

三路线已比较，选定 C 的 AS4-PAYLOAD/1 条件方案：WSL2 Ubuntu-24.04＋systemd，AS 1 GiB/进程＋单批父 slice TasksMax=4。原 Windows WS4 的 E2=UNRESOLVED；cgroup memory.max 允许暂时超限，未登记为原指标通过。E1 CONDITIONAL_PASS，E3 静态设计完成附条件，E4 PARTIAL_UNAUTHORIZED；F1/F4 仍 UNRUN_RESOURCE_GATE。

本机只读清单显示三个 WSL2 发行版均 Stopped；Docker 固定本地端点查询失败；实际 kernel/cgroup/systemd/native Python 未认证。新增代码/校准/模型/平台启动/配置/安装均0。batch01 原62文件/ZIP和27次、118.7340827秒保持；v3 未改。下一步先审合同边界和有限平台 P 阶段申请，再据实际信息冻结最终批次锁。

原协议1.1、G覆盖、I1/I2/I3归档、严格分离0与 IMPLEMENTATION_GATE=CLOSED 保持。Repair 根导航快照在 revisions/DCL-R6-Repair；以下保留历史入口，当前状态以前置 Envelope 节为准。

---
# 去中心化凭据生命周期：R6-B-Repair当前入口

2026-11-10。[本轮裁决](DCL-R6-Repair/FINAL_DECISION.md)、[修复索引](DCL-R6-Repair/README.md)、[资源界证明责任](DCL-R6-Repair/RESOURCE_BOUND_PROOF.md)为当前交付。

完成原ZIP/版本/计数复核、Windows API与布局/时窗审查，v3独立静态修订只改资源三文件，业务五文件hash一致。87唯一根因及峰值内部计账仍待取证；启动前包络未证，v3未执行且正式准入有意关闭。

RG-1 CONDITIONAL_PASS、RG-2 PARTIAL、RG-3 UNRUN并保持RESOURCE_GATE_FAILED、RG-4 UNRUN_RESOURCE_GATE。F1/F4未恢复，新增校准/模型0，PASS_BOUNDED为空。batch01已到期；新批次草案含独立授权和严格技术前置。

原62文件/60项ZIP、v1/v2、27/118.7340827旧账及R1–R5保持。原生/外发/依赖安装0，主机制门CLOSED、零分离与强G覆盖维持。下方为历史入口。

---
# 去中心化凭据生命周期：DCL-R6阶段B当前入口

2026-11-10。[最终裁决](DCL-R6/R6_FINAL_DECISION.md)、[资源校准失败报告](DCL-R6/R6_RESOURCE_CALIBRATION_REPORT.md)和[机器结果](DCL-R6/evidence/stage_B/RUN_RESULTS.json)为最新交付。

专项授权已执行到资源校准：八程序创建，v1/v2及首次失败保留；normal/counter通过，memory峰值断言失败，RESOURCE_GATE_FAILED。F1/F4未启动，均UNRUN_RESOURCE_GATE；正式模型反例0、PASS_BOUNDED为空。

B1 FAIL、B2/B3 UNRUN、B4 CONDITIONAL_PASS。27次访问全部校准，118.7340827秒至v2退出，未重置总账。实际指标/采样下界/未测峰值分列，现有证据不足以认证全部授权硬界，未绕过失败运行模型。

原协议1.1及D2条件结论/强G覆盖保留，机制实现门CLOSED，严格分离0，原生/构建/依赖下载/外发0。R1–R5冻结，R6阶段A已锁存，独立batch01保留源码、日志、计数与结果。

以下为阶段A和更早历史。

---
# 去中心化凭据生命周期：DCL-R6阶段A当前入口

2026-11-10。[最终裁决](DCL-R6/R6_FINAL_DECISION.md)、[R6索引](DCL-R6/README.md)与[专项申请](DCL-R6/R6_TOOLCHAIN_AND_PERMISSION.md)为当前交付。

本轮已完成只读工具/规格预审：F1八个不变量、多配置/独立RHO监视、K1/U2与变异；F4阈值算法/独立具体轨迹参考、输入合法性、夹具和G64族；资源硬界/工具缺口及命令范围明确。

阶段B尚无单独许可，F1/F4结果UNRUN_PERMISSION；模型/参考/监督程序创建0、模型执行0、下载/原生请求/外发0。仅Java/Python版本查询2次，行政检查分列。当前没有PASS_BOUNDED/LEVEL-3结果。

R6-A CONDITIONAL_PASS，B UNRUN_PERMISSION，C CONDITIONAL_PASS，D PASS于决策。D1/D2纸面条件、强G覆盖/I1–I3归档、严格分离0、机制实现门CLOSED保持。R5原件/盲审包直接复用，根四份旧导航/历史单独锁存。

下方保留历史入口。

---
# 去中心化凭据生命周期：DCL-R5当前入口

2026-11-10。[最终裁决](DCL-R5/R5_FINAL_DECISION.md)、[R5索引](DCL-R5/README.md)和[证据索引](DCL-R5/R5_SOURCE_INDEX.json)汇总本轮增量。

重点结果：旧签名Stop与完整child激活/可信摘要锚分层；Ready与真实使用时点/在途责任限定；官方发行asset摘要匹配、固定版本stamp写入及SQLite静态配置证据；S2(T)备用当前资格与全部资源前缀复核。

F1–F4和T1–T4已形成准入申请材料，代码/工具/fixture/权限仍待绑定，当前未执行。原生计划完整展开最多92次、硬封顶114次，NC2清理均分已修正。第一阶段盲审只含定义/命题/实例/空白返回表，原R4完整审查ZIP复用，外部复核0。

R5-A CONDITIONAL_PASS、B PARTIAL、C CONDITIONAL_PASS、D PASS。强G覆盖/I1–I3归档保留，严格分离0，实现门CLOSED。D1/D2仍属纸面条件协议/有限配置成果，实际PBFT/跨域S2和独立原创性另待证。

历史内容与R4原件保留如下；R5对资格时点、冷备用和预算的澄清以当前文稿为准。

---
# 去中心化凭据生命周期：DCL-R4 当前入口

2026-11-10。当前交付为[最终裁决](DCL-R4/R4_FINAL_DECISION.md)与[完整R4索引](DCL-R4/README.md)。[本地独立审查包](DCL-R4/R4_EXTERNAL_REVIEW_PACKAGE.md)包含协议/证明、原生合同、强G、反例、未解责任及验证计划；外部独立审查仍为0。

本轮收敛：D1-PBFT-SEAL/1.1纸面条件完整；D2有限累计费用/共同策略规格条件闭合；A/B/C部署映射PARTIAL；B按S1与有限S2(T)分别裁决。单/双Gate共主Q在Seal时失去S2，独立持续路径的故障、网络、期限和费用条件已具体化。

当前原生二进制有dirty标记，源码到运行精确对应持续待证。强G覆盖和I1/I2/I3归档保留；严格分离0，实现门CLOSED。新增代码/原生实验/机器证明/外发0。原33输入和R1/R2/R3归档保持，哈希/链接检查只承担工件完整性。

规范优先级：R3固定业务/BFT/费用/组合文稿＋R4明确增量与具体合同。历史入口全文在下方按原内容保留，旧状态仅代表当时证据。

---
# 去中心化凭据生命周期：D1 / D2 研究交付 DCL-R3

定稿日期：2026-11-10，Asia/Shanghai。DCL-R3继续原研究；R1的46份工件、R2的94份活动工件分别固定在revisions/DCL-R1与revisions/DCL-R2，锁定清单在evidence/r2与evidence/r3。原33输入保留。

本阶段入口：[NC1/NC2重新推导](R3_INDEPENDENT_CONCURRENCY_AUDIT.md)、[入口与创建截止](R3_NATIVE_ENTRY_CUT_AUDIT.md)、[具体BFT重配置](D1/BFT_RECONFIGURATION_PROTOCOL.md)、[证明与部署义务](D1/PROOF_OBLIGATIONS_R3.md)、[费用语义](D2/COST_SEMANTICS_R3.md)、[组合合同](JOINT/R3_COMPOSITION_CONTRACT.md)、[两轮强G反证](R3_STRONG_G_REASSESSMENT.md)、[原创性/状态裁决](R3_NOVELTY_DECISION.md)。

R3规范优先级：上述R3合同/实例/证明限定R2的21业务转换；R2文稿和历史证据保持原版本，未将后来结论改写成过去已经验证。CONDITIONAL_PROTOCOL_COMPLETE限纸面实例；原强B前缀支持仍由D2检验，单路径暂停场景不能通过。

R2阶段入口（历史）：[Casdoor能力审计](CASDOOR_NATIVE_CONTRACT_AUDIT.md)、[全部转换与原生轨迹](NATIVE_SEMANTICS_REFINEMENT.md)、[直接先例对照](DIRECT_PRIOR_WORK_COMPARISON.md)、[强G与四项分离反驳](STRONG_G_COVERAGE_AUDIT.md)。R2当时为Gate A静态范围通过、Gate B来源缺口、Gate C协议精化待证，实现门关闭。

本目录给出条件协议、联合配置模型、反例、强通用组合覆盖构造及后续验证设计。当前具有可审查的技术规格；严格优势实例、机器证明和外部独立复核仍待取得。实现门保持关闭。

建议阅读顺序：

1. [当前裁决](CURRENT_VERDICT.md)与[现状审查](CURRENT_STATE_AUDIT.md)。
2. [分离声明与实现门](SEPARATION_GATE.md)、[最强适用组合 G](BASELINE_G.md)。
3. [D1 协议](D1/PROTOCOL_SPEC.md)、[安全性质与证明](D1/SECURITY_PROPERTIES.md)、[反例](D1/PROOFS_AND_COUNTEREXAMPLES.md)。
4. [D2 模型](D2/CONFIGURATION_MODEL.md)、[算法及证书](D2/ALGORITHM_AND_CERTIFICATES.md)、[正确性](D2/CORRECTNESS_AND_PROOFS.md)。
5. [集成架构](JOINT/INTEGRATED_ARCHITECTURE.md)、[组合证明责任](JOINT/COMPOSITION_PROOF_OBLIGATIONS.md)。
6. [先例核验](SOURCE_AND_PRIOR_WORK.md)、[验证计划](EVALUATION_PLAN.md)、[下一步](NEXT_ACTION.md)。

evidence/INPUT_MANIFEST.json 固定 33 份本地输入的 SHA-256；evidence/web/ 保存本轮 18 批公开检索及正文定位结果，public_sources/ 保存 Crossref 元数据。哈希承担版本识别；语义与证明由正文中的论证承担。检索资料按实际取得范围使用，全文未核验项保留缺口。

以上18批为R1；R2新增公开正文定位保存于evidence/r2/web，26份固定版本源码及13项18字段能力记录保存于evidence/r2/native。R2_SOURCE_INDEX.json与CLAIM_LEDGER_R2.json汇总新证据及状态；文档完整性检查不承担协议验证。

本轮活动：源码与既有证据只读检查、公开资料检索、手工状态轨迹、条件证明、研究文档整理。新增机制代码、求解器实验、历史测试重跑、原生账号操作和外部发送均为 0。所有研究推导由当前对话内知情模型辅助完成；外部独立评审尚待取得。
