"""Future authorized entry. One foreground WSL invocation; no diagnostics or retry."""
import argparse
from pathlib import Path
import hashlib
import json
import subprocess


def main():
    p=argparse.ArgumentParser();p.add_argument('--activate',action='store_true',required=True);p.parse_args()
    package=Path(__file__).resolve().parents[1]
    lock=json.loads((package/'inputs/execution_lock.json').read_text(encoding='utf-8'))
    receipt_path=Path(r'D:\毕业设计\research_main_innovation\decentralized_credential_lifecycle\DCL-R6-batch07\evidence\execution_authorization.json')
    auth=json.loads(receipt_path.read_text(encoding='utf-8'))
    h=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
    if auth['execution_lock_sha256']!=h(package/'inputs/execution_lock.json') or auth['static_manifest_sha256']!=h(package/'inputs/static_manifest.json'):raise SystemExit('AUTHORIZATION_HASH_MISMATCH')
    if auth.get('SingleSession_exec_explicitly_approved') is not True or lock['windows_entry_sha256']!=h(Path(__file__)):raise SystemExit('ENTRY_NOT_APPROVED')
    for rel,expected in json.loads((package/'inputs/static_manifest.json').read_text())['source_hashes'].items():
        if h(package/'src'/rel)!=expected:raise SystemExit('SOURCE_DRIFT')
    out=receipt_path.parent/'windows_entry.stdout.raw';err=receipt_path.parent/'windows_entry.stderr.raw'
    plan={'argv':lock['windows_single_call'],'status':'REQUESTED_ONLY','source_mode':'SOURCE_ONLY/1'}
    (receipt_path.parent/'WINDOWS_ENTRY_PLAN.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
    with out.open('xb') as stdout,err.open('xb') as stderr:
        process=subprocess.Popen(lock['windows_single_call'],stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
        code=process.wait()
    # Exit status is process evidence; resource qualification still needs native receipts.
    (receipt_path.parent/'WINDOWS_ENTRY_EXIT.json').write_text(json.dumps({'exit_code':code,'wsl_client_pid':process.pid,'resource_gate':'REQUIRES_NATIVE_EVIDENCE'}),encoding='utf-8')
    raise SystemExit(code)


if __name__=='__main__':main()
