> 可移交阅读副本。数学正文、章节和式号沿用冻结原件；仅转换链接、添加行定位锚点及本说明。[冻结原件](../../frozen/crypto_fi_research_manuscript_v1/CRYPTOANALYSIS_DRAFT.md)。历史命令按来源记录保留；本包公开重放入口为根目录 REPLAY.md。

# FrodoPKE型可更新加密的公开仿射支撑区分：原游戏攻击、共同正确族与假设边界

研究稿v1，2026-11-10。知情修订、证明整合与学术写作。引用对象为DOI **10.46298/fi.14425** 的FI论文及arXiv:2410.03948v4。本文是供密码学人工审阅的研究稿，来源、数学复核和应用优先权各有明确范围。

## 摘要

本文分析FI发表的FrodoPKE型可更新加密构造。其更新第一块满足公开仿射关系Y=HP₁+RP₂。当token中的方阵P₂可逆时，对手可恢复候选更新随机向量并检验其有限支持。我们给出原rand-ind-eu-cpa游戏中四次查询的合法区分器，Key腐化、普通更新和随机带请求均为0。利用诚实父密文的低重量界和token独立误差矩阵的卷积反集中，我们直接控制真实fresh事件，逐个固定公开矩阵A及P₂得到β≤αε_n。仅依据P₂选择首个可逆边界，可在真实轮换预算内放大优势。在CF-1打印参数族中，完整初始噪声与最长n次更新同时满足逐样本正确性，攻击优势趋近1。官方三组有限误差表另给可重放的误接受证书。

我们同时限定条件安全声明的含义。CF-1的固定25点误差支持，在丰富独立同秘密样本接口下可由成熟有界误差代数方法处理；本文附完整2幂环证明及算法合同。固定n/3n样本、FI省略归约和实际作者程序分别保留责任。因此确定贡献是具体构造的来源隐藏失败、定量参数分析和证明范围审计。方法归属承认已有代数、概率、采样及重随机化分析，不主张通用密码分析技术首创。

关键词：可更新加密；来源隐藏；有限支持；反集中；LWE；条件安全；正确性。

## 1. 对象、贡献与结论范围

### 1.1 冻结发表对象

Jurkiewicz–Prabucka的 *Unidirectional Key Update in Updatable Encryption, Revisited* [S1] 在Theorem6.9声明：LWE假设下，所给构造在backward-leak uni-directional的rand-ind-eu-cpa模型安全。2026-11-10从出版社重新取得的[期刊PDF](../../frozen/crypto_fi_research_manuscript_v1/sources/FI_journal_20261110.pdf)共23页，464697字节，SHA-256为

`bc48416b8b88c989ecf98e2d466d10b80d13fd72d88890d905bc3b991ca3d0d4`。

它与冻结arXiv:2410.03948v4逐字节相同。v4修订日为2025-12-29；PDF首页印2025，出版社记在线发表2026-01-11。本文同时给出DOI、版本与哈希，避免仅用年份辨识对象。安全游戏定位PDF pp9–11，FrodoPKE和UE算法pp12–14，正确性p15，混合和定理pp18–20。源排版文件为[articlev08.tex](../../frozen/crypto_fi_research_manuscript_v1/sources/articlev08.tex)。

本文采用两项显式解释：Ord按实际输入列数参数化；标χ的坐标和调用在理想模型中独立抽样。前者补齐源文类型记号，后者明确打印采样合同。作者性能代码、秘密噪声seed联合律及实际失败语义尚未完成映射。结论首先绑定这一固定发表算法的数学模型。

### 1.2 贡献与近邻

本文给出四项可审核结果：原游戏合法高效事件；任意预先固定A下真实fresh的直接概率界；同一正确参数族和真实查询预算下的放大；源LWE前提与命名混合端点的范围审计。

Klooß–Lehmann–Rupp2019 [S3] 已给固定上下文的分布匹配要求，并在AppB.2说明公开token可揭露确定性更新的混合不一致。矩阵求逆、有限支持成员检查、卷积收缩、并集界、秩计数和停止放大均属成熟工具。本文对象增量在于把这些工具接到FI具体公式、权限与真实分布，补足参数和共同正确性。AG/CJL有界误差线性化[S4,S5]在本文作为假设适用性工具，算法及证明完整列于附录A。

截至2026-11-08的已封存定向检索及指定原文核读，尚未定位相同FI对象、相同原游戏轨迹的公开攻击。这个结论受检索范围约束；全球应用优先权仍待进一步核准。2026-11-10的新增检索只核期刊身份和参考文献题录。

### 1.3 最强可引用结论

在§2的打印公式、Ord规范化和独立有限表采样合同下，对每个先固定的A，原游戏存在不依赖计算困难性的合法PPT区分器。CF-1族中，它使用至多3n+1次oracle调用，且与最长n次更新的逐样本正确性同时成立，优势为1−negl(λ)。这个结论与“某一明确LWE困难性前提成立而Theorem6.9结论失败”分别评价：丰富样本前提在CF-1中已失效，固定样本前提及完整归约仍未认证。

## 2. 打印算法、类型与采样合同

### 2.1 记号与FrodoPKE

令R_q=Z/(q)，q=2^D，D≥1。χ表示整数误差表推送到R_q的分布，支持为\(\mathcal S\)，h=|\(\mathcal S\)|，a=max_zχ(z)。若整数支持为[−s,s]且q>2s，则h=2s+1，负数以q−|z|表示。所有矩阵计算在R_q中进行。\(\|X\|_{max}\)表示最大坐标绝对值，使用整数小量时取其声明的有符号代表。

全局A∈R_q^(n×n)在后续χ抽样前固定。FI.Setup均匀选择A；下文攻击定理逐个A成立，故覆盖它，也覆盖先确定A的公开seed展开。每代钥匙为

\[
S_e,E_e\leftarrow\chi^{n\times\bar n},\quad
B_e=AS_e+E_e,\quad k_e=(S_e,B_e).
\tag{1}
\]

Enc以独立U,F←χ^(m̄×n)、G←χ^(m̄×n̄)返回

\[
C_1=UA+F,\qquad C_2=UB_e+G+\operatorname{Encode}(M).
\tag{2}
\]

解密为Decode(C₂−C₁S_e)。每坐标承载B位，编码间隔q/2^B；相对编码的整数误差落在[−q/2^(B+1),q/2^(B+1))即正确[S1, Lemma5.1, p12]。完整key含两个矩阵；本攻击不请求它。epoch和消息登记由游戏维护，打印密文仅含(C₁,C₂)。

### 2.2 Ord与Tensor-D的类型规范化

源p13把Ord域写成m̄×n̄，p14却用于m̄×n的C₁，TG同时提供nD行。按逐位定义规范化为

\[
\operatorname{Ord}_t:R_q^{\bar m\times t}\to\{0,1\}^{\bar m\times tD}.
\]

若c_(j,b)为第j坐标第b位，一行输出按位平面排列：

\[
(c_{1,0},\ldots,c_{t,0},c_{1,1},\ldots,c_{t,1},\ldots,c_{1,D-1},\ldots,c_{t,D-1}).
\]

本对象取t=n。令Tensor_D(S)=[S;2S;…;2^(D−1)S]，则

\[
\operatorname{Ord}_n(C_1)\operatorname{Tensor}_D(S)=C_1S\pmod q.
\tag{3}
\]

逐位配方、TG行数和源Remark6.1共同确定这一记号补齐。字面域在n≠n̄时有类型缺口；本文透明携带此解释。新增噪声、改变矩阵形状或隐藏原返回字段属于另一个对象。

### 2.3 token与更新

每个边界独立采样：U₁,F₁∈χ^(nD×n)，G₁∈χ^(nD×n̄)；U₂,F₂∈χ^(n×n)，G₂∈χ^(n×n̄)。从old到new的token为

\[
\begin{aligned}
P_1&=U_1A+F_1,&Q_1&=U_1B_{new}+G_1-\operatorname{Tensor}_D(S_{old}),\\
P_2&=U_2A+F_2,&Q_2&=U_2B_{new}+G_2.
\end{aligned}\tag{4}
\]

它完整返回((P₁,Q₁),(P₂,Q₂))。P₁/Q₁各有nD行，P₂/Q₂各有n行；第一块列数n，第二块列数n̄。P₂确为n×n方阵。对父(C₁,C₂)，Upd仅新采R←χ^(m̄×n)，置H=Ord_n(C₁)，返回

\[
Y=HP_1+RP_2,\qquad Z=C_2+HQ_1+RQ_2.
\tag{5}
\]

打印TG没有可逆筛选/重试，Upd没有式(5)之外的新加性噪声[S1,p14；TeX L633–653]。χ640由独立16位反CDF精确抽样，每次固定消耗位数，抽样失败概率为0。实际程序若采用相关seed或拒绝机制，须另证联合律和失败损失。

本文的选择和输出只读取父第一块、P₁/P₂及挑战第一块；完整父仍按返回值提交。Q块、C₂和key的相关性由原算法保留，未通过错误的完整视图独立假设删去。

## 3. 四次查询的原游戏攻击

### 3.1 游戏权限与终局

FI原实验以epoch0、phase=0、泄露集合\(\mathcal K=\mathcal T=\mathcal C=\varnothing\)开始；集合\(\mathcal T\)与轮换上界T分别使用。固定M，执行：

| 次序 | 查询 | 源游戏行与状态 |
|---|---|---|
| 1 | C←Enc₀(M) | p9 Enc L1–4登记(qid,C,0;M) |
| 2 | Next到epoch1 | p10 Next L1–3生成key₁/token₁；phase=0，L4–7的挑战更新分支跳过 |
| 3 | Δ₁←Corr(token,1) | p9 Corr L1、L6–8返回存在的完整token，\(\mathcal T=\{1\}\) |
| 4 | C*←Challenge₁(M,C) | p10 Chall L1–5检查唯一挑战及上一代登记父；b=0作Enc，b=1作Upd；L10–12登记\(\mathcal C=\{1\}\)并返回 |

随后立即输出。父消息和fresh消息相同，源程序没有消息不等检查。Key、普通Upd、Dec、随机带和挑战后继读取均为0。Next在挑战前完成，未产生挑战后继登记。

backward钥匙闭包满足CorrK(e)=(e∈\(\mathcal K\))∨(CorrK(e+1)且e+1∈\(\mathcal T\))，越过已生成epoch的基值为false。故\(\mathcal K=\varnothing\)推出\(\mathcal K^*=\varnothing\)、\(\mathcal T^*=\mathcal T\)。p11把挑战闭包\(\mathcal C^*\)的具体生成转引Jiang，但无论得到哪个允许的\(\mathcal C^*\)，都有\(\mathcal K^*\cap\mathcal C^*=\varnothing\)。因此终局不会触发该失效条件；Dec相关的平凡获胜分支也没有被调用。这一证明无需从外部来源补写\(\mathcal C^*\)精确值。

### 3.2 公开支撑判定器与编码

取父第一块第一行c，H=Ord_n(c)，挑战第一块第一行y。四次查询后：

1. 若P₂奇异，输出一枚新的独立公平比特。
2. 否则求R_q上的逆，并算\(\hat r=(y-HP_1)P_2^{-1}\)。
3. 若\(\hat r\in\mathcal S^n\)，输出1（update）；否则输出0（fresh）。

奇数主元消元或mod2消元配合提升给出多项式时间运算。P₂可逆等价于det(P₂)为奇数，也等价于mod2满秩。update时式(5)给\(\hat r=r\)精确成立，故必通过。支持检查按模代表执行，不需要更新随机带或秘密。

算法验证矩阵尺寸、模数和返回格式；异常或⊥时以独立公平比特结束。理想原算法中合法查询的异常事件概率为0；实际错误响应/采样失败另行计费，不能据此延长理想优势界。

令E为fresh中存在r∈\(\mathcal S^n\)使y=HP₁+rP₂的事件；可逆时与支撑通过等价。定义

\[
\alpha=\Pr[P_2\text{可逆}],\quad
\beta=\Pr_{fresh}[P_2\text{可逆}\land E].
\]

两个实验的父/token前缀同分布。于是输出1的概率分别为α+(1−α)/2与β+(1−α)/2。本文统一使用

\[
\Delta=\Pr[\mathrm{Exp}_1=1]-\Pr[\mathrm{Exp}_0=1]
=\alpha-\beta.\tag{6}
\]

原文absolute gap/Adv为|Δ|；本攻击Δ≥0。均匀隐藏位下成功率为(1+Δ)/2，成功偏差bias为Δ/2。全部m̄行检查也可采用；下文真实fresh界的指数保持n。

## 4. 真实fresh的固定A概率定理

### 4.1 卷积与父重量

在R_q加法群上令μ_w=||χ^{*w}||∞。对分布P,Q，

\[
\|P*Q\|_\infty\le\|P\|_\infty,
\tag{7}
\]

因为每个卷积点是P各点的Q加权平均。故w≥w₀时μ_w≤μ_w₀，长和发生模回绕也不影响此式。

父第一行为c=u₀A+f₀。给定A,u₀后，每坐标是独立χ平移，为0概率≤a。若w=|Ord_n(c)|，每个非零坐标至少贡献一个1，故w小于w₀蕴含至少n−w₀+1个零坐标。对这些坐标集取并集得

\[
\Pr[w<w_0\mid A]\le\binom n{w_0-1}a^{n-w_0+1}.
\tag{8}
\]

父必须是本轮新Enc的诚实父；根据父值筛选或采用已更新父，需要自己的分布证明。

### 4.2 定理1：逐个P₂的条件界

**定理1。** 采用§2合同，固定任意A。对1≤w₀≤n，置

\[
\varepsilon_n=\min\left\{1,
\binom n{w_0-1}a^{n-w_0+1}+(h\mu_{w_0})^n\right\}.
\tag{9}
\]

对每个有正概率的P₂=p，Pr_fresh(E|A,P₂=p)≤ε_n。因此

\[
\beta\le\alpha\varepsilon_n,\qquad
\Delta\ge\alpha(1-\varepsilon_n).
\tag{10}
\]

**证明。** 固定A,P₂=p。父的u₀/f₀与该token块独立，故(8)仍成立。高重量部分进一步固定父第一行/H、U₁及fresh第一行y，保留F₁未条件化。真实fresh的y=u_f A+f_f与F₁独立；token中的Q₁也没有使用F₁。对每个固定r，事件要求

\[
HF_1=y-HU_1A-rp.\tag{11}
\]

右侧固定。H选择w个不同F₁行，各列独立，列和服从χ^{*w}。w≥w₀时，(11)概率≤μ_w₀^n。对h^n个固定r并集，再平均条件量，得到高重量贡献≤(hμ_w₀)^n。与(8)相加、截为1得到条件界。乘可逆指示并对P₂平均即得β≤αε_n，结合(6)完成证明。□

条件化有三个必要边界。其一，未同时固定P₁和U₁，否则F₁会被确定。其二，计算出的r̂可依赖P₁，但上述所有固定r的并集已经覆盖这种数据依赖。其三，update的y包含HF₁，不能在固定update y后沿用fresh独立性；它由精确恢复处理。

省略字段投影保持实际查询与输出：消息固定，父直接取刚返回的完整Enc输出，登记资格由生成调用确定，停止仅看P₂。因而证明只需该真实边缘分布，无需把整个fresh视图替换成均匀，也不需要LWE混合假设。

## 5. 自适应首次可逆边界

**算法A_k。** 对j=1,…,k，在epoch j−1新做Enc(M)，Next到j，读取token_j。P₂,j首次可逆时，用这一轮父作唯一Challenge并按§3判定，立即结束。全部奇异时独立公平输出。原程序没有强制必须挑战的终局检查；若采用固定一次挑战的记账习惯，也可在全失败路径发起并忽略最后一份合法挑战，概率相同。

最坏各k次Enc、Next、token腐化，Challenge≤1，合计≤3k+1。挑战后Next为0。停止于J时\(\mathcal K^*=\varnothing\)、\(\mathcal T^*=\mathcal T=\{1,\ldots,J\}\)、\(\mathcal C=\{J\}\)；全失败路径同样合法。T表示Next次数/最大epoch标签，T次轮换访问0,…,T共T+1个状态[S1,p18]。

3k+1是本攻击的调用上界，源游戏对所有PPT量化，并未据此设置统一查询上限。更多普通查询是否能提供某个精确LWE接口，需要另作分布证明。

**定理2。** 令J仅依P₂序列的首次可逆位置，p_k=Pr[J≤k]，

\[
\beta_{selected}=\Pr_{fresh}[J\le k\land E_J].
\]

则

\[
\beta_{selected}\le p_k\varepsilon_n,\qquad
\Delta_k=p_k-\beta_{selected}\ge p_k(1-\varepsilon_n).
\tag{12}
\]

**证明。** 虚拟补全k轮独立诚实父/token和每轮独立fresh行，真实程序只读取至J的前缀。固定A及整份P₂序列后，J已确定；所选父的f₀、所选F₁和fake fresh保有定理1的抽样律。逐个P₂条件界因此给Pr(E_J|A,P₂序列)≤ε_n。乘1_{J≤k}并平均得到联合界。全失败公平输出与b独立，在两个实验中抵消。□

该定理绑定P₂-only停止和每轮一份新父。读取P₁或父特征后额外筛选不在该骨架内。k次真实轮换全部支付，未把token搜索当作免费预处理。

## 6. CF-1共同正确参数族

### 6.1 参数与精确采样

取整数λ≥2，定义

\[
n=8\lambda,\quad D=8\lceil\log_2n\rceil,\quad q=2^D,\quad
\bar m=\bar n=8,\quad B=2,\quad \chi=\chi_{640},\quad
T=k=t_{max}=n.\tag{13}
\]

T为Next次数/最大epoch标签；t_max为单条链的更新次数。消息长128位。n^8≤q<(2n)^8，D=O(logn)。χ640对0及每个正/负点的概率分子为

`[9288,8720,7216,5264,3384,1918,958,422,164,56,17,4,1]/65536`。

零点计一次，其余正负各计一次。独立16位反CDF精确实现该表，每个样本先解释为有符号整数，再嵌入R_q。D位环表示与16位采样输入分开；直接沿用uint16负数机器表示到大q需另行适配。

FI p11明写D∈Z>0等参数，CF-1是其打印域实例。官方2021接口[S2,§2.2,p14]限制D≤16，故严格官方API解释下CF-1采用扩展参数模型标签。打印域成员资格与LWE困难前提成立性分别评价。

### 6.2 定理3：完整残差正确性

**定理3。** 在式(13)同一参数/采样合同下，对每个A、全部诚实消息、钥匙、token和随机样本，最长n次更新均正确。

**证明。** 初始密文相对编码的残差满足

\[
C_2-C_1S_{old}-\operatorname{Encode}(M)
\equiv U E_{old}+G-FS_{old}\pmod q,
\]

故存在整数代表η₀且||η₀||max≤B₀=2ns²+s。由(3)–(5)，一次更新增加

\[
\delta=(HU_1+RU_2)E_{new}-(HF_1+RF_2)S_{new}+HG_1+RG_2.
\tag{14}
\]

所有小量坐标绝对值≤s。H为m̄×nD的0/1矩阵；U₁/F₁为nD×n，U₂/F₂为n×n，S_new/E_new为n×n̄，G₁/G₂分别nD×n̄、n×n̄。逐维求和给

\[
\begin{aligned}
\|HU_1E_{new}\|_{max},\|HF_1S_{new}\|_{max}&\le n^2Ds^2,\\
\|RU_2E_{new}\|_{max},\|RF_2S_{new}\|_{max}&\le n^2s^3,\\
\|HG_1\|_{max}&\le nDs,\qquad \|RG_2\|_{max}\le ns^2.
\end{aligned}
\]

所以W=2n²Ds²+2n²s³+nDs+ns²界住单次增加。递归取η_t=η₀+Σδ_j，是实际模残差的一致整数提升，即使个别矩阵中间乘积曾取模，仍有||η_t||max≤B₀+tW。

s=12时，

\[
B_0=288n+12,\quad W=288n^2D+3456n^2+12nD+144n.
\tag{15}
\]

n≥16给D≤4n，从而

\[
\begin{aligned}
B_0+nW
&\le1152n^4+3504n^3+144n^2+288n+12\\
&<1372n^4<8192n^4\le n^8/8\le q/8.
\end{aligned}\tag{16}
\]

以最小n=16除以n⁴即可检查1372界，其余正项比例随n递减。由B=2的解码区间，所有t≤n残差均正确，也保有该相对编码残差的无回绕代表。□

此处显式计入初始噪声，且直接从算法推导完整链。源Theorem6.3的epochs措辞、较松界及E维度的一处排版差异不承担本文额外正确性推断。

### 6.3 定理4：同族的接近最大优势与成本

χ640的奇偶质量各为1/2。固定A,U₂后，F₂ mod2使P₂ mod2为独立均匀二元矩阵。逐行计数得

\[
p_n=\Pr[P_2\text{可逆}]=\prod_{i=1}^n(1-2^{-i})>1/4.
\tag{17}
\]

例如保留前两项并对尾积用∏(1−x_i)≥1−Σx_i，即得统一常数下界。token第一块之间跨调用独立，故p_k=1−(1−p_n)^k。

取w₀=64。q≥2^32>128s，64重整数卷积无支持点合并，μ₆₄为固定常数。附录B的精确有理证书给a=1161/8192<1/4、γ=25μ₆₄<1/2。n≥64时

\[
\varepsilon_n=\min\{1,\binom n{63}a^{n-63}+\gamma^n\}
\le2^{126}n^{63}2^{-2n}+2^{-n}=\operatorname{negl}(\lambda).
\tag{18}
\]

n<64取ε_n=1；n=64的当前证书仍可截为1。结合定理2得

\[
\boxed{\Delta_n\ge[1-(1-p_n)^n](1-\varepsilon_n)
\ge1-(3/4)^n-\varepsilon_n=1-\operatorname{negl}(\lambda).}
\tag{19}
\]

这与定理3使用同一族，计算困难性假设数量为0。

| 资源口径 | 上界/精确尺寸 |
|---|---|
| 攻击调用 | 各≤n次Enc、Next、token腐化，Challenge≤1；合计≤3n+1 |
| token返回 | n(D+1)(n+n̄)个环元素，按D位占n(D+1)(n+n̄)D位 |
| key/密文 | key为2nn̄个环元素；密文为m̄(n+n̄)个环元素 |
| 含诚实计算的位时间 | 保守O(n⁴(D+1)³)，含矩阵乘法、固定表采样、秩检查及逆 |
| 攻击流式工作存储 | O(n²(D+1)²)位；原游戏保存全部历史的空间另外计入实验，仍为多项式 |
| 最大通信 | O(n³(D+1)²)位，计完整token和密文 |

均匀Setup的A消耗n²D位。最多k轮时，两挑战分支统一可用χ样本数上界

\[
2(k+1)n\bar n+k n(D+1)(2n+\bar n)
+(k+1)(2\bar mn+\bar m\bar n).
\tag{20}
\]

每样本16位，另计公平猜测位。最后一项采用fresh挑战的采样量，覆盖update挑战仅需m̄n个样本的情况。它补齐历史成本账本仅列update末项的口径，渐近界保持不变。

一个完整有限实例为n=128、D=56、q=2^56、λ=16、T=128。B₀+nW=41084030988<q/8=9007199254740992，ε₁₂₈≤2^-59，调用≤385，gap≥1−(3/4)^128−2^-59。这里n是维度，λ是形式化参数，与官方NIST安全位数分别使用。

## 7. 官方有限配置的证书与正确性边界

下表采用[S2]的640/976/1344参数及完整1344 CDF，保持理想独立采样。64重卷积峰值和完整两项和由精确整数证书认证，方法见附录B。

| (n,D,B,s) | γ=hμ₆₄（仅展示近似） | ε_n上界 | 单次原游戏gap下界 |
|---|---:|---:|---|
| (640,15,2,12) | 0.4429404864… | 2^-751 | p₆₄₀(1−2^-751) |
| (976,16,3,10) | 0.4518156480… | 2^-1118 | p₉₇₆(1−2^-1118) |
| (1344,16,4,6) | 0.4536082584… | 2^-1532 | L₁₃₄₄(1−2^-1532) |

640/976的α精确为(17)。修正1344的偶/奇质量分别32770/65536与32766/65536。令p_max=16385/32768、p_min=16383/32768，则逐个固定A,U₂有

\[
L_n:=\prod_{i=1}^n(1-p_{max}^i)\le\alpha\le
\prod_{i=1}^n(1-p_{min}^i)=:U_n.
\tag{21}
\]

证明：余维i子空间由i个主元比特限制描述；条件于其它比特，主元要求值的乘积概率介于p_min^i与p_max^i。逐行条件于已独立行并相乘即得。L₁₃₄₄≈0.2887397288961254。该秩细化的历史身份是知情推论，和三组卷积的独立重算范围分别登记。

证书约束真实fresh的第一行支撑事件，因而约束其与可逆性的联合概率。它没有把指数提升为m̄n，也没有认证全部视图均匀性或解密失败率。64重无合并条件分别为q>1536、1280、768；更长卷积由(7)处理。

官方三组初始最坏充分界B₀分别184332、195210、96774，解码半宽分别4096、4096、2048。该粗界不能认证相应UE的完整正确性；它本身也未证明发生实际解密错误。完整结论还需要各更新深度的联合残差概率、全部坐标解码失败预算、最大T、token复用依赖和作者程序配置。普通FrodoPKE/KEM失败率不能直接替代这些UE量。

作者性能程序/commit、实际D/B/CDF/T、秘密噪声seed域分离/复用、筛选重试、溢出/打包和失败语义仍缺。任意公开seedA展开可对固定A定理直接平均；秘密噪声流保持独立χ的迁移另有责任。若实际第b实验输出概率与理想模型偏差≤ν_b，则实际gap至少max{0,理想gap−ν₀−ν₁}。

## 8. 精确LWE前提的适用性

### 8.1 实验、样本与量词

为区别正文行秘密，本节LWE采用列秘密：s∈R_q^n，A_samp∈R_q^(m×n)，b=A_samp s+e。NF取s←χ^n，US取s均匀；e←χ^m，各行系数独立均匀。决定实验与独立均匀b比较，优势为输出概率差；搜索实验要求输出s。[S2,Definitions2.7–2.9,pp12–13]明确保留m。

固定NF_n、NF_(n+8)、US_3n和US_(3n+8)各是不同的精确问题。官方FrodoPKE Theorem5.9使用前两个NF归约项；Theorem5.10和ACPS的转换[S6]给

\[
\operatorname{Adv}_{NF}(n,m,q,\chi;D)
\le\operatorname{Adv}_{US}(n,m+n+\rho,q,\chi;B)+2^{-\rho}.
\tag{22}
\]

ρ=n分别得到3n、3n+8源样本。ρ是本转换的预处理置信参数，与下文US提升的κ分别计数。附录A.6给完整变换与条件化。这个方向不把丰富样本US算法变成固定n样本NF算法。

丰富样本H_rich则允许同一秘密、任意多项式数量的新独立均匀行和新独立精确χ640误差，并量化所有PPT时间次数。共享A的不同秘密列没有因此变成同秘密更多行。实际Enc/Upd产生的复合误差、跨行相关和未知秘密相关字段也须另证联合模拟；重复行或线性组合会改变独立性/误差表。

### 8.2 丰富样本的已审阅结论

附录A给成熟线性化方法在2幂环上的完整算法及自含证明。令N=binom(n+25,25)，q₀=2^27，η=2^-16，gcd(25!,q₀)=2^22。训练只用b⁺=b+12，恢复模数为32。对正整数τ，取

\[
M=2^{20}(27N+\tau+1),\qquad \delta_{train}<e^{-8\tau}.
\tag{23}
\]

NF的秘密支持映到mod32单射，M份样本足以完整恢复。US再用n+κ份独立原模数新样本识别误差并无噪声求解，成功率≥1−δ_train−2^-κ。直接判定只增加t份独立留出数据，使用原始b，gap≥1−δ_train−(25/32)^t。

M=Θ(N+τ)，训练主项O((N+τ)N²)，后处理及原始位长成本按附录A.4另列。τ=t=κ=λ时才使用Θ(n^25)样本、O(n^75)密集时间和O(n^50)存储这一组简写。它们是可行上界，尚无最优性或必要成本下界。n=128时指定训练约需2^120份样本，与128/384份输入的固定问题分别评价。

因此CF-1的精确NF/US丰富样本PPT困难性已经失效；经典算法也包含于QPT类。固定样本同预算算法与困难性真实性继续未决。更宽Gaussian的宽度、尾部和最坏格归约[S7；S2 pp39–40]不能凭“近似Gaussian”自动转给固定25点表。AG原素数域证明及Steiner的域上Gröbner分析[S4,S8]也未单独提供当前少样本2幂环结论。

## 9. 混合端点与Theorem6.9的准确评价

### 9.1 命名步骤的公开事件

FI p18的Hyb_i在挑战epoch j≥i时返回random ciphertext，其余上下文保持真实；同页Sim.Enc/Sim.Upd定义为独立均匀两块。以下见证采用这一上下文解释，token端点仍真实。令Φ为可逆且所有m̄行均通过支撑检查的事件，\(\theta=(h/q)^{\bar mn}\)。挑战epoch1、b=1时，

\[
\Pr[\mathrm{Hyb}_0\text{接受}]=\Pr[\mathrm{Hyb}_1\text{接受}]=\alpha\theta,
\quad\Pr[\mathrm{Hyb}_2\text{接受}]=\alpha.
\tag{24}
\]

这是条件于可逆P₂的仿射双射计数；真实update一定通过。

p19另均匀独立选择U,fwl,fwr∈{0,…,T}，腐化token₁仅在fwr=0时触发abort。唯一不同位置为U=1。对相同abort响应核，中止部分抵消，Eq(6)所比较的输出概率差为

\[
\frac{T}{(T+1)^2}\,\alpha(1-\theta).
\tag{25}
\]

T=1时为α(1−θ)/4；CF-1的T=n时为Ω(1/n)。源abort输出未完整规定，本见证明确采用共同响应核。独立端点律、random含义及真实token端点随结论携带。这定位Eq(6)/Lemma6.8的可忽略性目标，不单独裁定前面的firewall缩放不等式。

### 9.2 条件句分情况

FI p19/TeX L872–877仅写LWE assumption并省略Lemma6.8证明，援引Nishimaki扩展版Lemma5.7；p20/TeX L882–886给Theorem6.9。其唯一的(n,m,q,χ,秘密先验,辅助视图,时间,对手类别)补全尚未恢复。

若H明确等于CF-1精确χ640的H_rich，§8和附录A已经给¬H；条件句H⇒Sec_CF1在该族是前件失效的情形，CF-1无法提供非空困难前提下的反例。若H限定固定n/3n样本，则其真实性、同预算算法与FI完整归约仍须认证。若H采用更宽Gaussian，则还须到精确有限表及完整UE视图的归约。

定理1–4和式(24)–(25)的数学内容不依赖上述H。它们认证具体构造不安全及声明端点的范围障碍；“困难前提已认证成立且条件安全蕴含为假”的资格单列未决。Nishimaki2024扩展版原图缺项影响继承论证和引用归属，未成为本文固定A攻击/正确性证明的引理。

## 10. 主任务关系、贡献与限制

### 10.1 业务合同的真实对应

ONLINE_TRUSTED_STATE_V1的早期fixture投影只覆盖controller/cache故障域和独立authority/provider/secure路径。该投影所指574字节environment.json哈希于本轮复核一致；它属于dev01历史fixture，不能概括后来的M5/M6权限验收。2026-11-06的CASDOOR_NATIVE_ISOLATED_V1及2026-11-09的G1合同交接各有版本和边界[E4]。

| 需求/输入 | 已有业务证据 | 与FI的对应状态 |
|---|---|---|
| 业务接纳权限 | caller/task/account/audience/generation、rid/digest及事务预算 | 与UE钥匙/token腐化权限尚无实验映射 |
| 材料托管 | AES-GCM状态、独立secure目录、TLS、受限令牌/DACL；M6真实材料与访问负例 | 支持限定部署机密性；没有实例化式(4)–(5)更新 |
| 公开token | 代理持服务能力/任务句柄；审计RSA公钥用于单向封存 | 这些对象均未建立为FI公开更新token Δ |
| 来源与版本 | 运行需要保留origin、attempt、version及审计归属 | 尚无合同要求fresh/update计算不可区分 |
| 原生撤回/处置 | LOCAL_REVOKE_COMMITTED阻止旧批准新放行；指定UserInfo/内省、已知处置及条件对账 | AS/RP接受和效果截止由原生证据承担，与来源隐藏游戏分开 |

故本文可作为主论文的独立密码分析章节或核心案例：说明选用UE时应单独核查来源隐藏及完整安全归约。当前证据没有把FI攻击转成已部署凭据系统失效，也未通过新增保护机制的实现门。

### 10.2 执行范围与历史分母

| 历史批次 | 允许引用的分母/范围 |
|---|---|
| M1 | 21槽，20通过/1初始化中止；假provider，原生请求0 |
| M2 | 4条原生轨迹，原评分3通过/1告警，离线修订4通过；补核/清理知识另记 |
| M3/M4 | 各2条关闭轨迹；分别依赖标识点读、额外授权组织范围与单Find等前提 |
| M5 | 合成材料12项权限场景；141项开发回归，原生请求0 |
| M6 | 2条各一次，每条43项检查；正式历史84个原生HTTP预算槽及对应审计密文；原版本148项回归 |
| 后续证据口径修订 | 2026-11-06 closure源码版本157项回归，保留与M5/M6旧版本的区别 |

这些是历史报告的有限验收，未在本轮重跑。本文修稿新增原生AS/RP请求、密码攻击/保护机制实现、作者联系和邮件均为0。G1-2026-11-09-r01仍将实现定位LIMITED_NATIVE_PROTOTYPE，真实端到端精化为SOURCE_OR_REFINEMENT_GAP。

### 10.3 贡献与下一项人工审阅

本文保持**具体UE来源隐藏密码分析与证明审计核心候选**的定位。精确有限概率、共同正确族和低调用原游戏事件为其对象价值；通用方法归属、实际程序、全球优先权和业务集成分别评价。

最值得人工密码学审阅的外部问题是：FI Lemma6.8究竟嵌入哪个未知秘密、得到多少同秘密独立样本，公开token的其余辅助字段如何同时模拟，以及该归约是否保持源参数与时间。数学复核则可优先检查定理1的F₁保留和定理2的P₂-only选择，以及附录A形式高次坐标的处理。

原PDF身份缺项的作用已分开：CJL影响方法引文的逐版本认证，自含证明仍可复核；Nishimaki扩展版影响继承/引用；作者程序影响性能实例与采样迁移。核心定理在声明合同内当前没有登记的未闭合证明步骤，合同外推广和条件定理的非空困难前提保持明确责任。

## 附录A　有界误差LWE的完整纸面算法与证明

### A.1 形式坐标与部分恢复命题

取正整数c,n,d，q₀=2^c，R=Z/(q₀)。秘密s∈R^n固定，各样本a_i独立均匀，e_i独立于a_i且跨样本独立，整数支持{0,…,d−1}的每点概率≥η>0。置

\[
V_d=\bigoplus_{|\alpha|\le d}R X^\alpha,\quad
N=\binom{n+d}{d},\quad F_d(T)=\prod_{j=0}^{d-1}(T-j).
\]

对y₀=1定义R线性泛函ℓ_y(Σc_αX^α)=Σc_αy_α；高次y_α保留为形式坐标，无需乘法一致。训练约束为ℓ_y(F_d(b_i−〈a_i,X〉))=0。

**定理5。** 令g=gcd(d!,q₀)。除概率至多

\[
\delta_M=\min\{1,q_0^{N-1}(1-\eta/2)^M\}
\tag{A1}
\]

以外，每个线性化解的一次项都等于s mod(q₀/g)。结论逐个s成立，故可对任意先验秘密平均。q₀/g=1时为平凡端点。式(A1)也蕴含历史稿较松的q₀^N界。

### A.2 确定选解与异常分支

以下为纸面算法描述，未实现LWE求解器。

**部分恢复PR(n,d,c,M)。**

1. 验证正整数参数和恰有M份格式合法的n维系数/响应；使用标准模代表。统一按总次数升序、同次数指数向量字典序降序排列单项式，常数最先，其后一次项依X₁,…,X_n排列。按组合计数预先给出单项式编号及乘X_j后的编号，超次数项作边界标记。
2. 逐个乘入d个常数/线性因子，构造P_i(X)=F_d(b_i−〈a_i,X〉)的模q₀系数。固定y₀=1，将常数移到右侧，得M×(N−1)系统Cy=h。保留C,h原值供核查；工作副本为C_w,h_w。
3. 在剩余子阵选v₂最小非零项，v₂(0)=c；平手按当前行、列编号确定。交换到对角位置。写主元2^u w，w为奇数，仅对w取逆，将主元化为2^u。对主元列其它项a取k满足2^u k=a modq₀，以行加倍数消去；再以列加倍数消去主元行。其余项可被2^u整除，故k可取标准整数代表除以2^u后的值。
4. 行操作同步更新h_w。记U为按确定顺序发生的初等行操作乘积，其作用可由原输入重放，运行中无需保存整个M×M矩阵或全日志。列操作以V显式记录，初始为单位阵，维持C_w=UCV、h_w=Uh。列加倍数/交换均同步更新V。
5. 无剩余非零项时停止。非零对角方程2^u z=h_w有解恰当且仅当右侧被2^u整除；取z=h_w/2^u mod2^(c−u)的最小非负代表，自由高位置0。零行要求右侧为0，自由坐标置0。返回原坐标y=Vz，并补回y₀=1。
6. 非零右侧的零行、不可整除对角方程、非法长度/模数或最终Cy=h核查失败均返回⊥。成功时仅输出一次项对q₀/g的余数。核查针对形式线性系统，高次坐标继续按形式变量处理。

每次主元去掉一行一列，最多N−1次；只有奇数单位被求逆。非单位除法同时降低模数，例如2z=2 mod4变为z=1 mod2并选择z=1，2z=1 mod4返回⊥。真实模型总含s的单项式解，故相容；任意⊥在成功概率中作为失败。

为明确展开尺寸而非隐含稀疏求解假设，令L=ceil(log₂(M+N+n+d+c+D+2))，D为原样本环元素位长。按密集系数与预计算编号，可采用保守位上界

\[
O\big((M+N)N^2c^2+MdnN(c+L)^2+ndNL^2+M(n+1)D\big),
\tag{A2}
\]

存储上界O((MN+N²)c+M(n+1)D+ndNL)。行变换作用右侧、列变换和原系统核查均包含在内；需要保存完整操作日志的另一个计划应追加其成本。密集消元可扫描子阵、复制主元行并顺序更新，不依赖额外的随机寻址免费假设。

### A.3 定理5的证明

定义T_s f(X)=f(s−X)。T_s²=Id，且按次数分块三角、对角元为(−1)^|α|。令

\[
z_\alpha=\ell_y((s-X)^\alpha)
=\sum_{\beta\le\alpha}\binom\alpha\beta
s^{\alpha-\beta}(-1)^{|\beta|}y_\beta.
\tag{A3}
\]

则z₀=1、z_(1)=s−y_(1)，并有ℓ_z(f(Z))=ℓ_y(f(s−X))。因此候选的原约束等价于ℓ_z(F_d(〈a,Z〉+e))=0。此推导覆盖乘法不一致的高次候选，s只用于分析。

整数恒等式ΔF_d(T)=dF_(d−1)(T)，迭代含d=1的零次差分端点，给

\[
\sum_{j=0}^{d-1}(-1)^{d-1-j}\binom{d-1}{j}F_d(T+j)=d!T.
\tag{A4}
\]

取T=〈a,Z〉并施加ℓ_z，高次和常数抵消，右侧为〈a,d!z_(1)〉。若y_(1)不同于s mod(q₀/g)，则v=d!z_(1)非零。令u=min_jv₂(v_j)<c。映射a↦〈a,v〉的像为2^uR，每个像点原像数相同；故非零概率1−2^(−(c−u))≥1/2。

对上述每个非零a，(A4)保证某j使其约束不成立；条件于a，误差仍取该j概率≥η。坏候选被一份样本排除概率至少η/2。先固定候选，再用M份独立性得存活概率≤(1−η/2)^M。y₀=1的候选共有q₀^(N−1)个，取并集得到(A1)。好事件同时约束整个解集，故覆盖A.2的数据依赖确定选解。最后d!u=0 modq₀等价于u=0 mod(q₀/g)，完成证明。□

这个证明采用成熟线性化、有限差分和环上线性代数，不需要单位满秩或Schwartz–Zippel。AG原§3/AppendixD采用素数域；CJL指定索引Lemma31提供prime-power对应来源。本文自含推导独立于其原PDF身份留项。

### A.4 CF-1包装、原响应与资源

训练保留原始样本(a_i,b_i)，另构造(a_i mod2^27,(b_i+12) mod2^27)，只把这份平移副本交PR。因为2^27|q，商映射保持均匀行和跨行独立；平移误差支持0,…,24、η=2^-16。v₂(25!)=22，恢复余数r=s mod32。取(23)，用1−x≤e^-x得

\[
\log\delta_{train}\le27N\ln2-8(27N+\tau+1)
=-27N(8-\ln2)-8\tau-8<-8\tau.
\tag{A5}
\]

**NF搜索。** PR返回⊥则返回⊥。对r每坐标在[−12,12]查唯一代表；缺失时返回⊥。将所得向量嵌回R_q，复核原始训练残差均属于支持，失败则返回⊥，否则输出。训练好事件G上r正确，支持映射和核查必通过，成功≥1−δ_train。

**US搜索。** PR后另取n+κ份独立、原模数新样本，保持原始b。计算u_i=(b_i−〈a_i,r〉) mod32，缺少支持代表时返回⊥；否则得到ê_i。按行编号依次选mod2增秩行，若最终不足n行则返回⊥。求所选子阵在R_q上的唯一解ŝ，并核查全部n+κ份新方程A_new ŝ=b_new−ê；失败返回⊥，成功输出ŝ。

G只依赖s和训练。条件于s、训练及G，后续矩阵和误差仍新独立，ê=e。非零二元向量的消去事件并集给失秩概率<(2^n)2^(−n−κ)=2^-κ；所选子阵行列式为奇数。因此

\[
m_{NF}=M,\quad P_{NF}\ge1-\delta_{train};\qquad
m_{US}=M+n+\kappa,\quad P_{US}\ge1-\delta_{train}-2^{-\kappa}.
\tag{A6}
\]

训练G不可由攻击者观察，所有估计/训练失败已通过δ_train计入；算法不以知道G为运行条件。

**直接判定。** 训练异常/⊥时输出0；否则另读t份独立留出样本，全部原始残差(b−〈a,r〉) mod32∈\(\mathcal S\) mod32时输出1，任何异常或失败输出0。这里1编码真实LWE，和正文UE编码分别定义。真实分支在G上必接受；均匀分支只条件于其自身整个训练，r固定，新b mod32仍独立均匀，即使进一步固定新a，每份通过概率仍为25/32。故

\[
m_{dec}=M+t,\quad
\Pr_{real}[1]-\Pr_{unif}[1]
\ge1-\delta_{train}-(25/32)^t.
\tag{A7}
\]

均匀分支未条件于真实G。训练无解时其接受为0，上界仍成立。三种包装均在非法格式、缺样本及核查失败时按搜索⊥/判定0处理；提前拒绝给最坏查询上界，读入并丢弃其余预定样本可固定查询数。误差η前提属于实验合同，算法无需从数据证明它。

一般τ保留M=Θ(N+τ)。固定d=25,c=27且τ,t,κ为任意指定多项式时，(A2)的索引项低于密集主项；训练时间O((N+τ)N²+(N+τ)(n+1)D)。三种包装合并的保守时间为

\[
O\big((N+\tau)N^2+(N+\tau+n+\kappa+t)(n+1)D
+(n+\kappa)n^2D^2\big).
\tag{A8}
\]

不运行的US或留出分支可令其相应成本为0。NF最终复核利用小秘密的固定坐标宽度，可纳入M nD项。保存完整输入的密集存储可界为O((N+τ)N+(N+τ+n+κ+t)(n+1)D)。τ次数很高时，训练主项随τ增长；若τ=O(n^(r_τ))，r_τ为固定非负常数，则主项为O(n^75+n^(50+r_τ))，并非无条件O(n^75)。超多项式置信参数使用完整(A2)，不声称PPT。

**专门取τ=t=κ=λ。** N=Θ(n^25)、D=O(logn)，训练Θ(n^25)样本，时间O(n^75)，密集存储O(n^50)；总原输入位长为(总样本数)(n+1)D=O(n^26logn)。US的新样本求解和留出成本均已包含。n=128时N=33542822544803763231686290281，M=949649364703984072529574454995451904；US总样本为M+144，直接判定为M+16。log₂(MN²)≈309.034860，log₂(27MN)≈219.029757，训练原输入M·129·56位。上述数量是指定计划的纸面规模，未测性能或证明最优性。

### A.5 精度加强的反例及其正确作用

取n=1、q₀=4、d=2、s=0，e均匀于{0,1}。形式向量y=(1,2,2)对所有a,e满足

\[
\ell_y(F_2(e-aX))=2a^2+2a(1-2e)
=2a(a+1)-4ae=0\pmod4.
\tag{A9}
\]

一次项2与s在mod4下不同，在定理5的mod2下相同；高次2也不同于一次项平方0。它反驳“每个形式解一次项直接完整恢复modq₀”的加强，不反驳部分恢复定理，也不排除利用部分信息和新样本另行完整恢复。

常数坐标须固定：若y₀自由，齐次系统总有全零向量。新样本独立性也有实际作用：q₀=4,d=1,e=0时复制一份均匀a共M次，错误候选s+2在a为偶数时始终存活，概率1/2；M=6时16·2^-6=1/4的独立样本式不适用于该复制输入。

### A.6 normal-form归约与固定样本边界

给定m+n+ρ份US行样本，前n+ρ份只依据mod2秩按编号选n行，成可逆A₀及b₀；其余m行A_R,b_R与前段独立。失败时输出共同常数。计算

\[
A'=-A_RA_0^{-1},\qquad b'=b_R-A_RA_0^{-1}b_0.
\tag{A10}
\]

真实分支b'=A'e₀+e_R。选行只用a，e₀仍独立χ；固定任何可逆A₀后，A_R↦A′是双射，故A′均匀且独立于e₀,e_R。无需额外固定b₀。均匀分支b_R独立均匀，b′仍独立均匀。预处理失败<2^-ρ，给(22)。方向为NF区分器→更多样本US区分器，与[S2,p38 Theorem5.10；S6,Lemma2]一致。

固定n或3n份样本缺少上述M及后续独立数据。共享A的L个不同秘密列只可按同m逐列混合，损失≤Σδ_j；其余列用给定A自采秘密生成，源样本仍为单列m。完整token的未知秘密相关辅助字段还需模拟。线性组合产生Σc_i e_i，改变支持/相关性；重复响应保留边缘却失去独立性。当前既无同预算扩样本算法，也无其普遍不可能性结论。

## 附录B　有限误差表与电子证书的重放规范

按0、+1/−1、…给每个原子的分子，分母均65536：

| χ | 分子序列 |
|---|---|
| 640 | 9288,8720,7216,5264,3384,1918,958,422,164,56,17,4,1 |
| 976 | 11278,10277,7774,4882,2545,1131,426,138,38,8,1 |
| 1344 | 18286,14320,6876,2023,364,40,2 |

χ640最小原子为2^-16，1344最小原子为2^-15；取2^-16作为后者的保守阈值仍有效。1344完整CDF为[9142,23462,30338,32361,32725,32765,32767]，规范曾遗漏32765，官方2024-11-27已确认[S10]。这一公开纠错归属原来源。

令整数质量c_z如表。由p₀(k)=1_{k=0}、p_(t+1)(k)=Σ_z c_z p_t(k−z)，精确得到64重和的整数系数，总质量为65536^64。其最大系数除以该分母给μ₆₄；q>128s确保这些支持点映入R_q时不合并。代入(9)检查完整两项有理数之和≤2^-751、2^-1118、2^-1532。浮点展示不承担界方向。

电子附录提供[总证书](../../frozen/crypto_fi_research_manuscript_v1/sources/PARAMETER_CERTIFICATES.json)和[640](../../frozen/crypto_fi_research_manuscript_v1/sources/chi_640_64fold_coefficients.json)、[976](../../frozen/crypto_fi_research_manuscript_v1/sources/chi_976_64fold_coefficients.json)、[1344](../../frozen/crypto_fi_research_manuscript_v1/sources/chi_1344_64fold_coefficients.json)完整系数。文件哈希分别为：

`38c6cce2750322f8d508187d030d34a754b0aea5bdb44d51a7e5693e2a10a546`

`180b3fc232aa06ef4951fbd335c80f06ed26328b2e7a02064a23c4a85d51bddc`

`62ef9f10b3ad09773456ba6ff9440f6837131a372b4ddb9991ac826625266386`。

计算是有限标量分布核对；一般证明由§4承担。读者可从上表和递推独立重建，或先核哈希再核完整系数及有理数式。

总证书中的历史绝对路径作为来源标记保留；本稿提供同名相对副本，按所列哈希对应，复核无需写回历史目录。

## 附录C　证据等级、身份与阅读定位

**原始规范。** [S1]的游戏pp9–11、算法pp12–14、正确性p15、混合pp18–20按同哈希原图核准；源TeX用于定位。2026-11-10重新下载认证当前期刊=v4，结构预检只认证读取结构。原文类型补齐、random/abort解释及采样合同均在正文显式列出。

**历史数学复核。** ROUND-005有一次两阶段AI流程：phase1只看冻结陈述和原始PDF、未见作者推导，phase2为同一审阅者读作者证明后的比对。F₁保留、逐P₂界、选择联合事件、三组卷积和CF-1按其封存范围沿用。1344秩细化和H1混合诊断保持知情来源身份。

**LWE定向审阅。** 目录名包含independent_review，其实际登记为AUTHOR_PROOF_VISIBLE_TARGETED_MATHEMATICAL_REVIEW；作者证明及历史结论可见。核心为PROVED_UNDER_STATED_MODEL，算法呈现/一般τ列REPAIR_REQUIRED。本稿在新目录落实修正。该包32项文件及规范化载荷校验均匹配。精确模型构建和作者/审阅模型分离程度未知，盲审、跨模型、人工及证明助手均为0。

**来源阅读范围。** [S2] Definitions2.7–2.9 pp12–13、Table3/4 p25、Theorems5.9/5.10 p38与Gaussian来源pp39–40；[S3]71页作者稿的p17 Def11、p27 Def14、p44 AppB.2；[S4]21页作者稿§3 pp7–10、AppendixD p19，原图pp8–9；[S6]23页作者稿pp9–10 Lemma2；[S7]37页作者稿p2模型/非正式主定理；[S8]32页v3的pp2–3、18及23。全文取得与定向阅读分别登记。

[S5]只取得2025-05-27索引节选，原索引L1192–1329、1332–1763及2891起用于Algorithm1、Lemma31/33–34、Proposition53；原PDF字节/原图及后续版本对应未知。自含附录A承担数学，未将转录哈希称作PDF哈希。[S9]扩展版Lemma5.7未认证。作者UE代码/config仍未取得。它们各自影响的方法归属、继承或实现声明已在§9–10区分。

本文由知情AI整合，尚未取得人工密码学同行意见。有限核对只涉及指定标量恒等式、概率证书、组合数、参数整数和文件哈希。当前主张—来源—量词与未决责任以[CLAIM_EVIDENCE_MATRIX.json](../../frozen/crypto_fi_research_manuscript_v1/CLAIM_EVIDENCE_MATRIX.json)为准。

## 参考文献与固定研究记录

- **[S1]** Mariusz Jurkiewicz, Kamila Prabucka. *Unidirectional Key Update in Updatable Encryption, Revisited*. Fundamenta Informaticae 194(4), Article4，PDF印2025，在线2026-01-11。DOI [10.46298/fi.14425](https://doi.org/10.46298/fi.14425)。arXiv:2410.03948v4，2025-12-29。本文固定23页期刊文件及其源TeX，哈希见§1.1。
- **[S2]** Erdem Alkim, Joppe W. Bos, Léo Ducas, Patrick Longa, Ilya Mironov, Michael Naehrig, Valeria Nikolaenko, Chris Peikert, Ananth Raghunathan, Douglas Stebila. *FrodoKEM: Learning With Errors Key Encapsulation—Algorithm Specifications and Supporting Documentation*. 2021-06-04，59页[冻结规范](../../frozen/crypto_fi_research_manuscript_v1/sources/official_frodo_2021.pdf)。SHA256 `5c3440b311c7ee4fba8b9a12e0ff567eb75c29fef66843f3eecc16f137164f7d`。
- **[S3]** Michael Klooß, Anja Lehmann, Andy Rupp. *(R)CCA Secure Updatable Encryption with Integrity Protection*. Advances in Cryptology—EUROCRYPT2019，pp68–99。DOI [10.1007/978-3-030-17653-2_3](https://doi.org/10.1007/978-3-030-17653-2_3)。[71页机构作者稿](../../frozen/crypto_fi_research_manuscript_v1/sources/KLR2019.pdf)，来源[ORBilu](https://orbilu.uni.lu/handle/10993/50226)，SHA256 `56a6e4533ae0d47ea6415eb898631353a11f55a47062ce04455dfd5aa811ba63`。
- **[S4]** Sanjeev Arora, Rong Ge. *New Algorithms for Learning in Presence of Errors*. ICALP2011, LNCS6755, pp403–415。DOI [10.1007/978-3-642-22006-7_34](https://doi.org/10.1007/978-3-642-22006-7_34)。本文读取[21页作者预印本](../../frozen/crypto_fi_research_manuscript_v1/sources/AG2011_author.pdf)，[作者来源](https://users.cs.duke.edu/~rongge/LPSN.pdf)，SHA256 `eec5d90ab7773eeac76257ff0b142ce5addbf26c88ea2a5a746242f7d8c13780`；与会议排版逐字节同一性未声称。
- **[S5]** Yilei Chen, Liheng Ji, Wenjie Li. *Learning with Alternating Moduli, Arora-Ge over Composite Moduli, and Weak PRFs*. [ePrint2025/968](https://eprint.iacr.org/2025/968)，本文使用日期2025-05-27的[指定索引节选](../../frozen/crypto_fi_research_manuscript_v1/sources/CJL2025_scoped_indexed_excerpts.txt)。CRYPTO2026题录：LNCS16802, pp201–231，DOI [10.1007/978-3-032-35377-1_7](https://doi.org/10.1007/978-3-032-35377-1_7)。原PDF及逐版本对应留项；本文不把题录认证扩大为公式原图认证。
- **[S6]** Benny Applebaum, David Cash, Chris Peikert, Amit Sahai. *Fast Cryptographic Primitives and Circular-Secure Encryption Based on Hard Learning Problems*. CRYPTO2009, LNCS5677, pp595–618。DOI [10.1007/978-3-642-03356-8_35](https://doi.org/10.1007/978-3-642-03356-8_35)。[23页作者稿](../../frozen/crypto_fi_research_manuscript_v1/sources/ACPS2009_author.pdf)，SHA256 `a9a67f7c1d25f8504c494e87fdc0ff636f53c3a87243bffe4df35d2a0910db1e`。
- **[S7]** Oded Regev. *On Lattices, Learning with Errors, Random Linear Codes, and Cryptography*. Journal of the ACM 56(6), Article34, 2009。DOI [10.1145/1568318.1568324](https://doi.org/10.1145/1568318.1568324)。本文使用[2009作者稿](../../frozen/crypto_fi_research_manuscript_v1/sources/Regev2009_author.pdf)，原始[作者端点](https://cims.nyu.edu/~regev/papers/qcrypto.pdf)。
- **[S8]** Matthias Johann Steiner. *The Complexity of Algebraic Algorithms for LWE*. [arXiv:2402.07852v3](https://arxiv.org/abs/2402.07852v3)，2025-03-29，32页。本文使用[冻结v3](../../frozen/crypto_fi_research_manuscript_v1/sources/Steiner2025v3.pdf)，SHA256 `859620bf7b97a5e4b89292586ac9cb825267e2699152a97723b507cf199b6852`。
- **[S9]** Ryo Nishimaki. *The Direction of Updatable Encryption Does Matter*. PKC2022；[ePrint2021/221](https://eprint.iacr.org/2021/221)。FI援引的2024扩展版§5/Lemma5.7原图与会议版本编号映射未完成核准，本条仅标识其继承来源责任。
- **[S10]** Microsoft PQCrypto-LWEKE. *CDF table of Frodo1344 different from specification*, [Issue35](https://github.com/microsoft/PQCrypto-LWEKE/issues/35)，2024-11-27；Patrick Longa同日回复确认Tχ(5)=32765、Tχ(6)=32767。参数勘误按已有公开事实引用。
- **[E1]** 项目封存研究记录：ROUND-005 `THEOREM_FOR_CITATION.md`、phase1/phase2数学审阅及清单，2026-11-07。定向范围和身份见附录C；属于AI辅助研究记录，非已发表文献。
- **[E2]** 项目封存研究记录：`crypto_fi_lwe_independent_review`，2026-11-10，作者证明可见的定向数学审阅，MANIFEST字节SHA256 `a0d5ed1bb2b608ea980c3200bec0c521384806c1a0e35bb94413cd4e5c674e72`。核心命题通过，呈现修正在本文落实。
- **[E3]** 项目来源/应用审计：`crypto_fi_original_game_decision`，2026-11-08；`crypto_fi_lwe_premise_audit`，2026-11-09。输入指纹、实读范围、检索回执和未决项由本稿MANIFEST固定。
- **[E4]** 主线证据：ONLINE_TRUSTED_STATE_V1的M1报告/架构；M1—M6总表、CASDOOR_NATIVE_ISOLATED_V1 profile及主体材料权限表，2026-11-06；`mainline_research_closure_v1`证据口径修订；G1-2026-11-09-r01交接。各日期、分母和实读文件哈希见`evidence/MAINLINE_SOURCE_LOCK.json`，仅作为本项目限定工程证据。

<!--protected-hedges: 截至2026-11-08的已封存定向检索及指定原文核读，尚未定位相同FI对象、相同原游戏轨迹的公开攻击。这个结论受检索范围约束；全球应用优先权仍待进一步核准。-->
